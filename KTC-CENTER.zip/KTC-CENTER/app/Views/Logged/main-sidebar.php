<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
     <!-- search form -->
        <form action="#" method="get" class="sidebar-form">
            <div class="input-group">
                <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
            </div>
        </form>
        <!-- /.search form -->
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu">
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-user-secret"></i> <span>Utilisateurs</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="?p=utilisateur.nouveau" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Nouvel Utilisateur</a></li>
                    <li><a href="?p=utilisateur.index" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Lister Utilisateurs</a></li>
                    <li><a href="?p=role.index" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Lister Rôles</a></li>
                </ul>
            </li>
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-laptop"></i>
                    <span>Administration</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="?p=time_table.index" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Emploi de temps</a></li>
                    <!-- Inscription -->
                    <li>
                        <a href="#"><i class="fa fa-pencil"></i> Caisse
                            <span class="pull-right-container">
                              <i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>
                        <ul class="treeview-menu">
                            <li><a href="?p=caisse.nouveau" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Nouveau versement</a></li>
                            <li><a href="?p=caisse.index" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Etat des caisses</a></li>
                            <li><a href="?p=etudant.fche-inscripton" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Fche d'nscrpton</a></li>
                        </ul>
                    </li>
                    <!-- Gestion des notes -->
                    <li>
                        <a href="#"><i class="fa fa-files-o"></i> Gestion des Notes
                            <span class="pull-right-container">
                              <i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>
                        <ul class="treeview-menu">
                            <li><a href="?p=evaluation.nouveau" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Saisir</a></li>
                            <li><a href="?p=evaluation.index" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Consulter</a></li>
                            <li><a href="?p=evaluation.pvm" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>PV par module</a></li>
                            <li><a href="?p=evaluation.pvs" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>PV par spécialité</a></li>
                            <li><a href="?p=evaluation.pvg" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>PV général</a></li>
                            <li><a href="?p=note.index" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Type Notes</a></li>
                        </ul>
                    </li>

                    <!-- Ressources humaines -->
                    <li>
                        <a href="#"><i class="fa fa-users"></i> Ressources Humaines
                            <span class="pull-right-container">
                              <i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>
                        <ul class="treeview-menu">
                            <li><a href="?p=enseignant.nouveau" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Nouveau Personnel</a></li>
                            <li><a href="?p=enseignant.index" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Lister Personnels</a></li>
                        </ul>
                    </li>
                </ul>
            </li>
            <!-- Gestion des formations -->
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-edit"></i> <span>Formations</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="?p=formation.nouveau" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Nouvelle Formation</a></li>
                    <li><a href="?p=formation.index" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Lister Formations</a></li>
                    <li><a href="?p=formation_type.index" class="afficher_sous_menu"><i class="fa fa-circle-o "></i>Lister Types</a></li>
                </ul>
            </li>
            <!-- Gestion des modules -->
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-folder"></i> <span>Modules</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="?p=module.nouveau" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Nouveau Module</a></li>
                    <li><a href="?p=module.index" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Lister Modules</a></li>
                    <li><a href="?p=formation_module.index" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Attribuer à une formation</a></li>
                </ul>
            </li>
            <!-- Gestion des etudiants-->
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-graduation-cap"></i> <span>Etudiants</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="?p=etudiant.nouveau" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Nouvel Etudiant</a></li>
                    <li><a href="?p=etudiant.index" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Lister Etudiants</a></li>
                </ul>
            </li>
      <!--      <li>
                <a href="?p=configurations.index" class="afficher_sous_menu" title="Afficher les configurations du système">
                    <i class="fa fa-cogs"></i> <span>Configurations</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-green">7</small>
            </span>
                </a>
            </li>     -->

            <li class="treeview">
                <a href="#">
                    <i class="fa fa-cogs"></i> <span>Configuration</span>
                     <span class="pull-right-container">
                      <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="?p=branche_activite.index" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Branches d'activité</a></li>
                    <li><a href="?p=contrat.index" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Contrats</a></li>
                    <li><a href="?p=diplome.index" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Diplômes</a></li>
                    <!--<li><a href="?p=evaluation.index" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Evaluation</a></li>-->
                    <li><a href="?p=filiere.index" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Filiere</a></li>
                    <li><a href="?p=fonction.index" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Fonctions</a></li>
                    <li><a href="?p=nature_formation.index" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Nature des fomations</a></li>
                    <li><a href="?p=secteur_activite.index" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Secteurs d'activité</a></li>
                    <li><a href="?p=specialite.index" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Spécialités</a></li>
                    <li><a href="?p=paramtre.index" class="afficher_sous_menu"><i class="fa fa-circle-o"></i>Système</a></li>
                </ul>
            </li>
        </ul>
    </section>
    <!-- /.sidebar -->
</aside>