<footer class="main-footer">

    <div class="pull-right hidden-xs">
      <b>KTC-MANAGER</b> 1.0
    </div>
    <strong>Copyright &copy; 2017 <a href="http://kamer-center.net">KTC-CENTER</a>.</strong> All rights
    reserved.
  </footer>
