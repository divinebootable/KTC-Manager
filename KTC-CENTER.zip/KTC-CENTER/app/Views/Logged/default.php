<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <title><?= App::getInstance()->title; ?></title>
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <?php require_once('css.php'); ?>
        <script src='https://www.google.com/recaptcha/api.js'></script>
    </head>

    <body class="hold-transition skin-blue fixed sidebar-mini">
        <div class="wrapper">
                <?php require_once('header.php'); ?>
                <?php require_once('main-sidebar.php'); ?>
             <!--   <div class="wrapper"> -->
                        <div class="content-wrapper">
                            <?= $content; ?>
                         </div>
           <!--     </div> -->
                <?php require_once('footer.php') ?>
        </div>
        <?php require_once('js.php'); ?>
    </body>
</html>
