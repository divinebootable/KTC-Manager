  <header class="main-header">
    <!-- Logo -->
    <a href="?p=home" class="logo" title="Accueil">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>A</b>LT</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>KTC-</b>CENTER</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu" style="margin-right: 5px;">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="dist/img/photo2.jpg" class="user-image" alt="User Image">
              <span class="hidden-xs"><?= $current_user->login; ?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="dist/img/photo2.jpg" class="img-circle" alt="User Image">

                <p>
                  <?= $current_user->nom.' '.$current_user->prenom; ?>
                  <small>Member since  <?= $current_user->date_save; ?></small>
                </p>
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="#" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="?p=login" class="btn btn-default btn-flat" id="deconnecter">Déconnexion</a>
                </div>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
    <div class="loader" style="display: none;"></div>
  </header>

