<div class="form-group">
    <label class="col-sm-2 control-label"  for="type_formation">Modules) sollicitée(s)<span class="obligatoire">*</span></label>
    <div class="col-sm-9">
        <select class="form-control select2 choix_formation" multiple="multiple" data-placeholder="Sélectionner le(s) modules(s) sollicitées" name="module_idmodule[]" required>
            <?php foreach($modules as $post): ?>
                <option value="<?= $post->idmodule; ?>"> <?= $post->nom_module; ?> </option>
            <?php endforeach; ?>
        </select>
    </div>
</div>
<script>
    $(".select2").select2();
</script>
