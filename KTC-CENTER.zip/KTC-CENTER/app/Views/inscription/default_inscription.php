<?= $content_inscription_ajax; ?>

