<?php
    $chemin = ROOT.'/app/Views/Logged/';
    $chemin = str_replace('\\', '/',$chemin );
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
        <title><?= App::getInstance()->title; ?></title>
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <?php require_once($chemin.'css.php'); ?>
        <?php require_once('header.php'); ?>
        <?php require_once('sidebar.php'); ?>    
    </head>

<body class="hold-transition skin-blue fixed sidebar-mini">
        <div class="wrapper">
                <div class="content-wrapper">
                    <?= $content_inscription; ?>
                 </div>
        </div>
        <?php require_once($chemin.'footer.php') ?>
        <?php require_once('js.php'); ?>
        <script src='https://www.google.com/recaptcha/api.js'></script>
    </body>
</html>
