<?php App::getInstance()->title = "KTC MANAGER|Nouvel Etudiant" ?>
<div style="font-size: 2em; text-align: center; font-weight: bold; color: #5280ea">INSCRIPTIONS DQP 2018 AU KTC-CENTER</div>

<section class="content">

    <div class="box box-default">
        <div class="box-header with-border">

		<?php if($_POST):
                    if($errors){?>
                        <div class="alert alert-danger col-sm-9 col-lg-offset-2">
                            <?= $message; ?>
                        </div>
                    <?php }else{?>
                        <div class="alert alert-success col-sm-9 col-lg-offset-2">
                            <?= $message; ?>
                        </div>
                    <?php } endif; ?>

          <h3 class="box-title">Formulaire d'inscription</h3> (
           <span style="font-style: italic;">Les champs avec <span class="obligatoire">*</span> Sont obligatoires</span>)

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
            <!--<button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>-->
          </div>
        </div>
        <!-- /.box-header -->
       <form class="form-add" method="post" action="?p=inscription.nouveau"> 
        <div class="box-body">
          <div class="row">

            <div class="col-md-6">
              <div class="form-group">
                <label>Nom(s)<span class="obligatoire">*</span></label>
                <div class="input-group">
                    <div class="input-group-addon">
                        <i class="fa fa-pencil"></i>
                    </div>
                        <input class="form-control" id="nom_personne" type="text" name="nom"  value="<?= $personne['nom'];?>" required   style="width:100%;"/>
                    </div>
              </div>

              <div class="form-group">
                <label>Prénom(s)</label>
                <div class="input-group">
                    <div class="input-group-addon">
                        <i class="fa fa-pencil-square"></i>
                    </div>
                     <input class="form-control " id="prenom_personne" type="text" name="prenom" value="<?= $personne['prenom'];?>" style="width:100%;" />
                   </div>  
              </div>

              <div class="form-group">
                <label>Date de naissance<span class="obligatoire">*</span></label>
                <div class="input-group date">
                  <div class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                  </div>
                  <input class="form-control pull-right datepicker" id="personne_date_naissance" type="text" name="date_naissance" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])/(0[1-9]|1[012])/[0-9]{4}" value="<?= $this->getDateFR($personne['date_naissance']);?>" placeholder="dd/mm/yyyy"  style="width:100%;"  required/>
                </div>
              </div> 

              <!-- /.form-group -->
              <div class="form-group">
                <label>Sexe<span class="obligatoire">*</span></label>
                <div class="input-group">
                    <div class="input-group-addon">
                        <i class="fa fa-intersex"></i>
                    </div>
                    <select class="form-control"  name="sexe" style="width:100%;" required>
                        <option disabled selected>Sélectionner le sexe</option>
                        <option value="FEMININ">FEMININ</option>
                        <option value="MASCULIN">MASCULIN</option>
                    </select>
                </div>    
              </div>
              <!-- /.form-group -->
            </div>

            <!-- /.col -->
            <div class="col-md-6">
              
              <div class="form-group">
                    <label>Téléphone<span class="obligatoire">*</span></label>
                    <div class="input-group">
                        <div class="input-group-addon">
                          <i class="fa fa-phone"></i>
                          </div>
                          <input class="form-control " id="telephone_personne" type="text" name="telephone" data-inputmask='"mask": "+(237) 999-999-999"' data-mask value="<?= $personne['telephone'];?>" style="width:100%;" required/>
                    </div>  
               </div>
              <!-- /.form-group -->
               
              <!-- /.form-group -->
              <div class="form-group">
                <label>Email<span class="obligatoire">*</span></label>
                <div class="input-group date">
                  <div class="input-group-addon">
                    <i class="fa fa-envelope"></i>
                  </div>
                  <input class="form-control" id="email_personne" type="email" name="email" pattern="^[a-z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$" placeholder="exemple@exemple.com" value="<?= $personne['email'];?>" style="width:100%;"  required />  
                  </div>              
              </div>
              <!-- /.form-group -->

              <div class="form-group">
                <label>Niveau d'étude<span class="obligatoire">*</span></label>
                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-graduation-cap"></i>
                  </div>
                    <select class="form-control"   name="diplome_iddiplome"  style="width:100%;" required>
                      <option selected disabled>Sélectionner le niveau d'étude</option>
                        <?php foreach($diplomes as $post): ?>
                        <option value="<?= $post->iddiplome; ?>"> <?= $post->type_diplome; ?> </option>
                        <?php endforeach; ?>
                    </select>
                   </div> 
              </div>
              
              
              <!-- /.form-group -->
              <div class="form-group">
                <label>Formation Sollicitée<span class="obligatoire">*</span></label>
                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-edit"></i>
                  </div>
                    <select class="form-control" name="formation_idformation" required>
                        <option selected disabled>Sélectionner une formation</option>
                        <?php foreach($formations as $post): ?>
                        <option value="<?= $post->idformation; ?>"> <?= $post->nom_formation; ?> </option>
                        <?php endforeach; ?>
                    </select>
                </div>                    
              </div>
               <!-- /.form-group -->

            </div>
            <!-- /.col -->
          </div>          <!-- /.row -->
          <div class="box-footer">
            <div class="g-recaptcha col-sm-6" data-sitekey="6Ld0CR8UAAAAAE8EPpJxkLRLRYL_MbqVCDCbLPj7"></div>
		<br>
            <div class="col-lg-offset-5 col-lg-10">
                <button class="btn btn-default" type="reset">Effacer</button>
                <button class="btn btn-primary" name="submit" type="submit"><i class="fa fa-check"></i> Enregistrer</button>
            </div>               
          
          </div> 

          <div class="box-footer">
            <span style="float: right; color:#5280ea; font-size: 1.1em;"><u>NB</u>: Seul le paiement des frais d'inscription vous garantit la place pour la formation choisie.
          </div>         
        </div>
       </form> 
        
        <!-- /.box-body -->       
    </div>

</section>

<style>
    .select2{
        width:100%;
    }
</style>
