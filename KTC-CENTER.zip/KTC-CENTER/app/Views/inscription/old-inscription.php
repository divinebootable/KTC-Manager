<?php App::getInstance()->title = "KTC MANAGER|Nouvel Etudiant" ?>
<div style="font-size: 2em; text-align: center; font-weight: bold; color: #5280ea">VACANCES UTILES A L'EEC</div>
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Enrégistrement d'un nouvel étudiant</h3>
                </div>
                <?php if($_POST):
                    if($errors){?>
                        <div class="alert alert-danger col-sm-9 col-lg-offset-2">
                            <?= $message; ?>
                        </div>
                    <?php }else{?>
                        <div class="alert alert-success col-sm-9 col-lg-offset-2">
                            <?= $message; ?>
                        </div>
                    <?php } endif; ?>

                <form class="form-horizontal form-add" method="post" action="?p=inscription.nouveau">
                    <div class="box-body with-border">
                        <div class="form-group">
                            <label class="col-sm-2 control-label" for="nom">Nom <span class="obligatoire">*</span></label>
                            <div class="col-sm-9">
                                <input class="form-control " id="nom_personne" type="text" name="nom"  value="<?= $personne['nom'];?>" required  />
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-2 control-label" for="prenom">Prenom </label>
                            <div class="col-sm-9">
                                <input class="form-control " id="prenom_personne" type="text" name="prenom" value="<?= $personne['prenom'];?>" />
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-2 control-label" for="sexe">Sexe<span class="obligatoire">*</span></label>
                            <div class="col-sm-9">
                                <select class="form-control select2"  name="sexe" required>
                                    <option disabled selected>Sélectionner le sexe</option>
                                    <option value="FEMININ">FEMININ</option>
                                    <option value="MASCULIN">MASCULIN</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group date">
                            <label class="col-sm-2 control-label" for="date">Date de naissance<span class="obligatoire">*</span></label>
                            <div class="col-sm-9">
                                <input class="form-control datepicker" id="personne_date_naissance" type="text" name="date_naissance" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])/(0[1-9]|1[012])/[0-9]{4}" value="<?= $this->getDateFR($personne['date_naissance']);?>" placeholder="dd/mm/yyyy"    required"/>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-2 control-label" for="personne_enseignant">Téléphone<span class="obligatoire">*</span></label>
                            <div class="col-sm-9">
                                <input class="form-control " id="telephone_personne" type="text" name="telephone" data-inputmask='"mask": "+(237) 999-999-999"' data-mask value="<?= $personne['telephone'];?>" required/>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-2 control-label" for="email">Email<span class="obligatoire">*</span></label>
                            <div class="col-sm-9">
                                <input class="form-control" id="email_personne" type="email" name="email" pattern="^[a-z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$" placeholder="exemple@exemple.com" value="<?= $personne['email'];?>"  required />
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-2 control-label"  for="type_formation">Niveau d'étude<span class="obligatoire">*</span></label>
                            <div class="col-sm-9">
                                <select class="form-control select2"   name="diplome_iddiplome" required>
                                    <option selected disabled>Sélectionner le niveau d'étude</option>
                                    <?php foreach($diplomes as $post): ?>
                                        <option value="<?= $post->iddiplome; ?>"> <?= $post->type_diplome; ?> </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-2 control-label"  for="type_formation">Formation(s) sollicitée(s)<span class="obligatoire">*</span></label>
                            <div class="col-sm-9">
                                <select class="form-control choix_formation" name="formation_idformation" required>
                                    <option selected disabled>Sélectionner une formation</option>
                                    <?php foreach($formations as $post): ?>
                                        <option value="<?= $post->idformation; ?>"> <?= $post->nom_formation; ?> </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div id="div_module">

                        </div>
                        <div class="form-group">
                            <label class="col-sm-2"></label>
                            <div class="g-recaptcha col-sm-9" data-sitekey="6Ld0CR8UAAAAAE8EPpJxkLRLRYL_MbqVCDCbLPj7"></div>
                        </div>

                    </div>

                    <div class="box-footer">
                        <div class="col-lg-offset-5 col-lg-10">
                            <button class="btn btn-default annuler" type="reset">Effacer</button>
                            <button class="btn btn-primary" name="submit" type="submit">Enregistrer</button>
                        </div>
                </form>
            </div>
        </div>
    </div>
</section>

<style>
    .select2{
        width:100%;
    }
</style>
