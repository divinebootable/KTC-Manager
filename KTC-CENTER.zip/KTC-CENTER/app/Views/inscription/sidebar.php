<aside class="main-sidebar">
    <section class="sidebar">
        <ul class="sidebar-menu">
            <li class="treeview">
                <img src="dist/img/logo-ktccenter.jpeg" width="100%" height="60px" class="user-image" alt="User Image">
            </li>
            <li class="treeview">
                <a  href="?p=inscription.nouveau" class=" afficher">
                    <i class="fa fa-graduation-cap"></i><span>Nouvelle inscription</span>
                </a>
            </li>           
        </ul>
    </section>
</aside>

