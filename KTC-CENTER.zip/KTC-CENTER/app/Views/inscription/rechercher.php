
<?php
    $val = $action == "modifier" ? "modifier" : "imprimer";
    App::getInstance()->title = "KTC MANAGER|Rechercher-".$val;
?>
<div style="font-size: 2em; text-align: center; font-weight: bold; color: #5280ea">VACANCES UTILES A L'EEC</div>
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <?php
                    if(!$exist){?>
                        <div class="alert alert-danger">
                            Code invalide
                        </div>
                    <?php }; ?>

                    <h3 class="box-title">Saisir le code votre fiche d'inscription</h3>
                    <form accept-charset="UTF-8" action="<?= htmlspecialchars($_SERVER['REQUEST_URI'], ENT_QUOTES); ?>" method="POST" class="sidebar-form form-horizontal">
                        <div class="input-group">
                            <label class="control-label"></label>
                            <input type="text" name="code" class="form-control" placeholder="Code..." required>
                              <span class="input-group-btn">
                                <button type="submit" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                                </button>
                              </span>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
