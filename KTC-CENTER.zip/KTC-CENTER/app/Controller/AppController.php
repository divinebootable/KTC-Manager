<?php
namespace App\Controller;
use Core\Controller\Controller;
use \App;
class AppController extends Controller{

    public function __construct($path="/app/Views/", $temp='login'){
       $this->viewPath = ROOT.$path;
       $this->template = $temp;
   }
   protected function loadModel($model_name){
       $this->$model_name =  App::getInstance()->getTable($model_name);
   }
}
?>