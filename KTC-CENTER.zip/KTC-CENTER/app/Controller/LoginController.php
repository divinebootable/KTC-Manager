<?php
namespace App\Controller;
use Core\Auth\DbAuth;
use Core\HTML\Form;
use \App;
class LoginController extends AppController{

    public function login(){
        $errors = false;
        $data = array('login'=>"", 'password'=>"");
        $param = App::getInstance()->getTable("parametre")->find(array('lisible'=>1));
        if(isset($_SESSION['auth']) && !empty($_SESSION['auth'])){
            session_unset();
            session_destroy();
        }else{
            if(!empty($_POST)){
                $data = array('login'=>$_POST['login'], 'password'=>$_POST['password']);
                $password = $_POST['password'];
                $auth = new DbAuth(App::getInstance()->getDb());
                if($auth->login($data['login'], $data['password'])){
                    header('Location:index.php?p=home');
                }else{
                    $errors = true;
                }
            }
        }
        $this->render('login', compact('data', 'param', 'errors'));
     }
  /*  public function verrouiller(){
        $errors = false;
        $data = array('login'=>"", 'password'=>"");
        $param = App::getInstance()->getTable("parametre")->find(1);

        if(!empty($_POST)){
            $data = array('login'=>$_POST['login'], 'password'=>$_POST['password']);
            $auth = new DbAuth(App::getInstance()->getDb());
            if($auth->login($data['login'], $data['password'])){
                header('Location:index.php?p=verrouiller');
            }else{
                $errors = true;
            }
        }
        $this->render('verrouiller', compact('data', 'param', 'errors'));
    }*/

    public function deconnecter(){
        session_unset();
        session_destroy();
        $errors = false;
       $data = array('login'=>"", 'password'=>"");
        $param = App::getInstance()->getTable("parametre")->find(array('lisible'=>1));
      //  $this->render('login', compact('data', 'param', 'errors'));
        $this->render('logged.index', compact('data', 'param', 'errors'));
    }
    public function introuvable(){
      $this->notFound();
    }



}
?>