<?php
namespace App\Controller;
use Core\Controller\Controller;
use \App;
class ReportController extends Controller{

    public function __construct($path="/app/Views/fichiers", $temp='login'){
        $this->viewPath = ROOT.$path;
        $this->template = $temp;
    }
    protected function loadModel($model_name){
        $this->$model_name =  App::getInstance()->getTable($model_name);
    }
}
?>