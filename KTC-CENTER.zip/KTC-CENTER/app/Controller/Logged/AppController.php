<?php
namespace App\Controller\Logged;
use Core\Auth\DbAuth;

class AppController extends \App\Controller\AppController{

    public function __construct(){
        $path = '/app/Views/Logged/';
        $temp = 'default';
        parent::__construct($path, $temp);
       $app = \App::getInstance();
        $auth = new DbAuth($app->getDb());
        if(!$auth->logged()){
            $this->forbidden();
        }
    }


  }
?>