<?php
namespace App\Controller\Logged;
class HomeController extends \App\Controller\Logged\AppController{
    public function __construct(){
        parent::__construct();
    }
    public function home(){
        $this->render('index', compact('user', 'param'));
    }
}
?>