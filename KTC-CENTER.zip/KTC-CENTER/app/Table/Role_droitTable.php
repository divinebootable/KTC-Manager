<?php


namespace App\Table;
use Core\Table\Table;
/**
 * Created by PhpStorm.
 * User: ppeyton
 * Date: 18/03/2017
 * Time: 22:28
 */
class Role_droitTable extends Table
{
    public function has($id){
        return $this->query("SELECT hasdroit, idrole FROM role_droit
                              INNER JOIN role ON role.idrole = role_droit.role_idrole
                              INNER JOIN droit ON droit.iddroit = role_droit.droit_iddroit
                              AND role_droit.lisible = ?
                              AND role.lisible = ?
                              AND droit.lisible = ?
                              AND iddroit = ?", array(1, 1, 1, $id));
    }
}