<?php


    namespace App\Table;
    use Core\Table\Table;
/**
 * Created by PhpStorm.
 * User: ppeyton
 * Date: 18/03/2017
 * Time: 22:28
 */
class PersonneTable extends Table
{
    public function all_user(){
        return $this->query("SELECT idpersonne, nom, prenom from personne
                                WHERE lisible = true
                                AND idpersonne NOT IN(SELECT personne_idpersonne from utilisateur
                                                        WHERE lisible = true)
                                ORDER BY nom");
    }
}