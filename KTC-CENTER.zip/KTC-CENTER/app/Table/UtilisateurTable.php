<?php


    namespace App\Table;
    use Core\Table\Table;
/**
 * Created by PhpStorm.
 * User: ppeyton
 * Date: 18/03/2017
 * Time: 22:28
 */
class UtilisateurTable extends Table
{
    public function all(){
        return $this->query("SELECT * FROM utilisateur
                                INNER JOIN personne ON personne_idpersonne = idpersonne
                                INNER JOIN utilisateur_role ON utilisateur_idutilisateur = idutilisateur
                                INNER JOIN role ON role_idrole = idrole
                                AND personne.lisible = ?
                                AND utilisateur.lisible = ?
                                AND role.lisible = ?
                                AND utilisateur_role.lisible = ?
                                AND utilisateur.login != ?
                                ORDER BY nom", array(1, 1, 1, 1, 'admin'));
    }

    public function getUser($id){
        return $this->query("SELECT * FROM utilisateur
                                INNER JOIN personne ON personne_idpersonne = idpersonne
                                INNER JOIN utilisateur_role ON utilisateur_idutilisateur = idutilisateur
                                INNER JOIN role ON role_idrole = idrole
                                AND personne.lisible = ?
                                AND utilisateur.lisible = ?
                                AND role.lisible = ?
                                AND utilisateur_role.lisible = ?
                                AND utilisateur.idutilisateur = ?", array(1, 1, 1, 1, $id), true);
    }
}