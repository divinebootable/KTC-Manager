<?php
    namespace App\Entity;
    use \Core\Entity\Entity;
    class RoleEntity extends  Entity{

        public function getModifier(){
            return "?p=role.modifier&id=".$this->idrole;
        }
        public function getSupprimer(){
            return "?p=role.supprimer&id=".$this->idrole;
        }
        public function getDroits(){
            return "?p=role.droits&id=".$this->idrole;
        }
    }
?>