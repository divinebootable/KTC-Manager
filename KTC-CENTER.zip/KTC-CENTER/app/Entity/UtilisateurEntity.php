<?php
    namespace App\Entity;
    use \Core\Entity\Entity;
    class UtilisateurEntity extends  Entity{

        public function getModifier(){
            return "?p=utilisateur.modifier&id=".$this->idutilisateur;
        }
        public function getSupprimer(){
            return "?p=utilisateur.supprimer&id=".$this->idutilisateur;
        }
        public function getShow_role(){
            return "?p=role.droits&id=".$this->idrole;
        }
    }
?>