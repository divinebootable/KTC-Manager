<?php
    namespace App\Entity;
    use \Core\Entity\Entity;
    class PersonneEntity extends  Entity{

    }
?>