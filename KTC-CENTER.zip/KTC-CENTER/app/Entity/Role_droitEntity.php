<?php
    namespace App\Entity;
    use \Core\Entity\Entity;
    class Role_droitEntity extends  Entity{


    }
?>