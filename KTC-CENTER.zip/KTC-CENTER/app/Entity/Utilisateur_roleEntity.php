<?php
    namespace App\Entity;
    use \Core\Entity\Entity;
    class Utilisateur_roleEntity extends  Entity{

        public function getModifier(){
            return "?p=utilisateur_role.modifier&id=".$this->idutilisateur_role;
        }
        public function getSupprimer(){
            return "?p=utilisateur_role.supprimer&id=".$this->idutilisateur_role;
        }
    }
?>