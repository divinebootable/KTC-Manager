<?php

    return array(

        "db_host" => "localhost",
        "db_nom" => "ktcmanager",
        "db_user" => "ktcmanager",
        "db_pass" => "ktcmanager#2017"


    );

?>