<?php


    namespace App\Table;
    use Core\Table\Table;
/**
 * Created by PhpStorm.
 * User: ppeyton
 * Date: 18/03/2017
 * Time: 22:28
 */
class DroitTable extends Table
{
   /* public function droits($idP){
        return $this->query("SELECT nomdroit, droit.description, iddroit FROM droit
                              INNER JOIN package ON package.idpackage = droit.package_idpackage
                              AND package.lisible = ?
                              AND droit.lisible = ?
                              AND package.idpackage = ?", array(1, 1, $idP));
    }*/
    public function droits($idpackage, $idrole){
        return $this->query("SELECT nomdroit, droit.description, hasdroit, idrole_droit FROM droit
                              INNER JOIN package ON package.idpackage = droit.package_idpackage
                              INNER JOIN role_droit ON role_droit.droit_iddroit = droit.iddroit
                              INNER JOIN role ON role_droit.role_idrole = role.idrole
                              AND package.lisible = ?
                              AND droit.lisible = ?
                              AND role_droit.lisible = ?
                              AND role.lisible = ?
                              AND package.idpackage = ?
                              AND role.idrole = ?", array(1, 1, 1, 1, $idpackage, $idrole));
    }
}