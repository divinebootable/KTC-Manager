<?php


    namespace App\Table;
    use Core\Table\Table;
/**
 * Created by PhpStorm.
 * User: ppeyton
 * Date: 18/03/2017
 * Time: 22:28
 */
class EnseignantTable extends Table
{
    public function all(){
        return $this->query("SELECT * FROM enseignant
                              INNER JOIN personnel ON enseignant.personnel_idpersonnel = personnel.idpersonnel
                              INNER JOIN personne ON personnel.personne_idpersonne = personne.idpersonne
                              INNER JOIN fonction ON personnel.fonction_idfonction = fonction.idfonction
                              INNER JOIN contrat ON personnel.contrat_idcontrat = contrat.idcontrat
                              INNER JOIN diplome ON personnel.diplome_iddiplome = diplome.iddiplome
                              INNER JOIN specialite ON enseignant.specialite_idspecialite = specialite.idspecialite
                               AND enseignant.lisible = ?
                               AND personnel.lisible = ?
                               AND personne.lisible = ?
                               AND fonction.lisible = ?
                               AND contrat.lisible = ?
                               AND diplome.lisible = ?
                               AND specialite.lisible = ?
                               ORDER BY personne.nom", array(1, 1, 1, 1, 1, 1, 1));
    }

    public function find($id){

        return $this->query("SELECT * FROM enseignant
                              INNER JOIN personnel ON enseignant.personnel_idpersonnel = personnel.idpersonnel
                              INNER JOIN personne ON personnel.personne_idpersonne = personne.idpersonne
                              INNER JOIN fonction ON personnel.fonction_idfonction = fonction.idfonction
                              INNER JOIN contrat ON personnel.contrat_idcontrat = contrat.idcontrat
                              INNER JOIN diplome ON personnel.diplome_iddiplome = diplome.iddiplome
                              INNER JOIN specialite ON enseignant.specialite_idspecialite = specialite.idspecialite
                               AND enseignant.lisible = ?
                               AND personnel.lisible = ?
                               AND personne.lisible = ?
                               AND fonction.lisible = ?
                               AND contrat.lisible = ?
                               AND diplome.lisible = ?
                               AND specialite.lisible = ?
                               AND idenseignant = ?
                               ORDER BY personne.nom", array(1, 1, 1, 1, 1, 1, 1, $id))[0];
    }
}