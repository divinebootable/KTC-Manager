<?php


namespace App\Table;
use Core\Table\Table;
/**
 * Created by PhpStorm.
 * User: ppeyton
 * Date: 18/03/2017
 * Time: 22:28
 */
class SpecialiteTable extends Table
{

}