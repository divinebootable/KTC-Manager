<?php


namespace App\Table;
use Core\Table\Table;
/**
 * Created by PhpStorm.
 * User: ppeyton
 * Date: 18/03/2017
 * Time: 22:28
 */
class EvaluationTable extends Table
{
    public function modules($id){
        return $this->query("SELECT idmodule, nom_module FROM module
                              INNER JOIN formation_module ON module_idmodule = idmodule
                              INNER JOIN formation ON formation_idformation = idformation
                              AND idformation = ?
                              AND formation.lisible = ?
                              AND module.lisible = ?
                              AND formation_module.lisible = ? ORDER BY nom_module ", array($id, 1, 1, 1), false);

    }

    public function notes($id){
        return $this->query("SELECT idnote, type_note FROM note
                              WHERE lisible = ?
                              AND idnote NOT IN(SELECT note_idnote FROM evaluation
                                                  WHERE module_idmodule = ?
                                                  AND lisible = ?)", array(1, $id, 1));
    }

    public function etudiants($idformation, $idmodule, $idnote){
        return $this->query("SELECT idetudiant, matricule, nom, prenom FROM etudiant
                              INNER JOIN personne ON personne_idpersonne = idpersonne
                              INNER JOIN formation_etudiant ON etudiant_idetudiant = idetudiant
                              AND formation_idformation = ?
                              AND personne.lisible = ?
                              AND etudiant.lisible = ?
                              AND formation_etudiant.lisible = ?
                              AND idetudiant NOT IN(SELECT etudiant_idetudiant FROM evaluation
                                                      WHERE module_idmodule = ?
                                                      AND note_idnote = ?
                                                      AND lisible = ?) ORDER BY nom", array($idformation, 1, 1, 1, $idmodule, $idnote, 1));
    }public function modules_consulter($id){
        return $this->query("SELECT idmodule, nom_module FROM module
                              INNER JOIN formation_module ON module_idmodule = idmodule
                              INNER JOIN formation ON formation_idformation = idformation
                              AND idformation = ?
                              AND formation.lisible = ?
                              AND module.lisible = ?
                              AND formation_module.lisible = ? ORDER BY nom_module ", array($id, 1, 1, 1), false);

    }

    public function notes_consulter($id){
        return $this->query("SELECT idnote, type_note FROM note
                              WHERE lisible = ?
                              AND idnote IN(SELECT note_idnote FROM evaluation
                                                  WHERE module_idmodule = ?
                                                  AND lisible = ?)", array(1, $id, 1));
    }

    public function etudiants_consulter($idformation, $idmodule, $idnote){
        return $this->query("SELECT idetudiant, matricule, nom, prenom, moyenne, idevaluation FROM evaluation
                              INNER JOIN etudiant ON etudiant_idetudiant = idetudiant
                              INNER JOIN personne ON personne_idpersonne = idpersonne
                              INNER JOIN module ON module_idmodule = idmodule
                              INNER JOIN note ON note_idnote = note.idnote
                              AND idnote = ?
                              AND idmodule = ?
                              AND personne.lisible = ?
                              AND etudiant.lisible = ?
                              AND evaluation.lisible = ?
                              AND note.lisible = ?
                              AND module.lisible = ?
                              ORDER BY nom", array($idnote, $idmodule, 1, 1, 1, 1, 1));
    }
}