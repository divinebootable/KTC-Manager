<?php


    namespace App\Table;
    use Core\Table\Table;
/**
 * Created by PhpStorm.
 * User: ppeyton
 * Date: 18/03/2017
 * Time: 22:28
 */
class Formation_etudiantTable extends Table
{

// ----------- Fonction retournant toutes les informations sur toutes les formations d'un étudiant (DEBUT) -------------
        public function find_id_formation($idetudiant){
            return $this->query("SELECT  * FROM formation
                                  INNER JOIN formation_etudiant ON formation_etudiant.formation_idformation = formation.idformation
                                  INNER JOIN formation_type ON formation_type.idformation_type = formation.	formation_type_idformation_type
                                  INNER JOIN etudiant ON etudiant.idetudiant = formation_etudiant.etudiant_idetudiant
                                  AND formation.lisible = ?
                                  AND etudiant.lisible = ?
                                  AND formation_etudiant.lisible = ?
                                  AND etudiant.idetudiant = ?", array(1, 1, 1,$idetudiant));
        }

        public function all(){
            return $this->query("SELECT idetudiant, matricule, nom, prenom FROM formation_etudiant
                                  INNER JOIN etudiant ON etudiant.idetudiant = formation_etudiant.etudiant_idetudiant
                                  INNER JOIN formation ON formation.idformation = formation_etudiant.formation_idformation
                                  INNER JOIN personne ON personne.idpersonne = etudiant.personne_idpersonne
                                  AND etudiant.lisible = ?
                                  AND personne.lisible = ?
                                  AND formation.lisible = ?
                                  AND formation_etudiant.lisible = ?", array(1, 1, 1, 1));
        }


//-------------------------------------------------------FIN -----------------------------------------------------------



}