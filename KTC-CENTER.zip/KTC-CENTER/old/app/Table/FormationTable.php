<?php
    namespace App\Table;
    use Core\Table\Table;
/**
 * Created by PhpStorm.
 * User: ppeyton
 * Date: 18/03/2017
 * Time: 22:28
 */
class FormationTable extends Table
{
    public function all(){
        return $this->query("SELECT * FROM formation
                                INNER JOIN formation_type ON formation_type.idformation_type = formation.formation_type_idformation_type
                                AND formation.lisible = ?
                                AND formation_type.lisible = ?", array(1, 1));
    }
    public function formation_etudiants(){
        return $this->query("SELECT *  from formation
                                INNER JOIN formation_type ON idformation_type = formation_type_idformation_type
                                AND formation.lisible = ?
                                AND formation_type.lisible = ?
                                AND formation_type.type!= ?", array(1,1, 'VACANCES UTILES'));
    }

    public function getOne($id){

        return $this->query("SELECT * FROM formation
                              INNER JOIN formation_type ON formation_type.idformation_type = formation.formation_type_idformation_type
                              INNER JOIN secteur_activite ON idsecteur_activite = secteur_activite_idsecteur_activite
                              INNER JOIN filiere ON idfiliere = filiere_idfiliere
                              INNER JOIN branche_activite ON idbranche_activite = branche_activite_idbranche_activite
                              INNER JOIN nature_formation ON idnature_formation = nature_formation_idnature_formation
                              INNER JOIN specialite ON idspecialite = specialite_idspecialite
                              INNER JOIN diplome ON iddiplome = diplome_iddiplome
                              AND formation.lisible = ?
                              AND formation_type.lisible = ?
                              AND secteur_activite.lisible = ?
                              AND filiere.lisible = ?
                              AND branche_activite.lisible = ?
                              AND nature_formation.lisible = ?
                              AND specialite.lisible = ?
                              AND diplome.lisible = ?
                              AND formation.idformation = ?", array(1, 1, 1, 1, 1, 1, 1, 1, $id), true);
    }

    public function getEtudiants($id){
        return $this->query("SELECT idetudiant, type_inscription, matricule, personne.nom as nom, prenom, sexe, formation_etudiant.date_save as date_etudiant FROM formation_etudiant
                              INNER JOIN formation ON formation.idformation = formation_etudiant.formation_idformation
                              INNER JOIN etudiant ON etudiant.idetudiant = formation_etudiant.etudiant_idetudiant
                              INNER JOIN personne ON personne.idpersonne = etudiant.personne_idpersonne
                              AND formation_etudiant.lisible = ?
                              AND formation.lisible = ?
                              AND etudiant.lisible = ?
                              AND personne.lisible = ?
                              AND etudiant.etat = ?
                              AND formation.idformation = ?", array(1, 1, 1, 1, 1, $id));
    }

    public function getModules($id){
        return $this->query("SELECT idmodule, code_module, nom_module, type_module, formation_module.date_save as date_module FROM formation_module
                               INNER JOIN formation ON formation.idformation = formation_module.formation_idformation
                               INNER JOIN module ON module.idmodule = formation_module.module_idmodule
                               AND formation_module.lisible = ?
                               AND formation.lisible = ?
                               AND module.lisible = ?
                               AND idformation = ?", array(1, 1, 1, $id));
    }

    public function liste_formation_vu(){
        $listes = $this->query("SELECT idformation FROM formation
                                INNER JOIN formation_type ON formation_type.idformation_type = formation.formation_type_idformation_type
                                AND formation.lisible = ?
                                AND formation_type.lisible = ?
                                AND formation_type.type = ?", array(1, 1, 'VACANCES UTILES'));
        $liste_id = array();
        foreach($listes as $liste){
            array_push($liste_id, $liste->idformation);
        }

        return $liste_id;
    }
}