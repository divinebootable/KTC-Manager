<?php


    namespace App\Table;
    use Core\Table\Table;
/**
 * Created by PhpStorm.
 * User: ppeyton
 * Date: 18/03/2017
 * Time: 22:28
 */
class EtudiantTable extends Table
{

    //--------------------------Fonction retournant tous les étudiants (DEBUT)------------------------------------------
    public function all(){
        return $this->query("SELECT * FROM etudiant
                              INNER JOIN personne ON etudiant.personne_idpersonne = personne.idpersonne
                              INNER JOIN diplome ON etudiant.diplome_iddiplome = diplome.iddiplome
                              INNER JOIN formation_etudiant ON formation_etudiant.etudiant_idetudiant = etudiant.idetudiant
                              INNER JOIN formation ON formation.idformation = formation_etudiant.formation_idformation
                              INNER JOIN formation_type ON formation.formation_type_idformation_type = formation_type.idformation_type
                               AND etudiant.lisible = ?
                               AND personne.lisible = ?
                               AND diplome.lisible = ?
                               AND formation.lisible = ?
                               AND formation_etudiant.lisible = ?
                               AND formation_type.lisible = ?
                               ORDER BY personne.nom", array(1, 1, 1, 1, 1, 1));
    }
    //------------------------------------------------------FIN---------------------------------------------------------

    //------------Fonction retournant un étudiant et toutes ses informamations à partir de son identifiant (DEBUT)------
    public function find($idetudiant){
        return $this->query("SELECT * FROM etudiant
                              INNER JOIN personne ON etudiant.personne_idpersonne = personne.idpersonne
                              INNER JOIN diplome ON etudiant.diplome_iddiplome = diplome.iddiplome
                              INNER JOIN formation_etudiant ON etudiant.idetudiant = formation_etudiant.etudiant_idetudiant
                              INNER JOIN formation ON formation_etudiant.formation_idformation = formation.idformation
                               AND idetudiant=?
                               AND etudiant.lisible = ?
                               AND personne.lisible = ?
                               AND diplome.lisible = ?
                               AND formation.lisible = ?
                               AND formation_etudiant.lisible = ?
                               ORDER BY personne.nom", array($idetudiant, 1, 1, 1,1,1), true);
    }
   //-------------------------------------------------------FIN---------------------------------------------------------

    //-------------------------------Fonction retournant un email si celui-ci existe (DEBUT)----------------------------
    public function find_email1($email){
        return $this->query("SELECT email FROM etudiant
                              INNER JOIN personne ON etudiant.personne_idpersonne = personne.idpersonne
                               AND etudiant.lisible = ?
                               AND personne.lisible = ?
                               AND personne.email = ?
                               ORDER BY personne.nom", array(1, 1, $email), true);

    }
    //------------------------------------------------------FIN---------------------------------------------------------

    //----------Fonction retournant un email si celui-ci existe en excluant celui d'un étudiant précis (DEBUT)----------
    public function find_email2($email, $idetudiant){
        return $this->query("SELECT email FROM etudiant
                              INNER JOIN personne ON etudiant.personne_idpersonne = personne.idpersonne
                               AND etudiant.lisible = ?
                               AND personne.lisible = ?
                               AND personne.email = ?
                               AND etudiant.idetudiant != ?
                               ORDER BY personne.nom", array(1, 1, $email, $idetudiant), true);

    }
    //------------------------------------------------------FIN---------------------------------------------------------

    //----------------------Fonction retournant le nombre de fidèle d'un sexe donné (DEBUT)-----------------------------
    public function nombre($sexe){
        return $this->query("SELECT count(idetudiant) as nombre FROM etudiant
                              INNER JOIN personne ON etudiant.personne_idpersonne = personne.idpersonne
                               AND personne.sexe = ?
                               ORDER BY personne.nom", array($sexe), true);

    }
 //---------------------------------------------------------FIN---------------------------------------------------------
    public function getNombre(){
        return $this->query("SELECT count(idetudiant) as nbre FROM etudiant WHERE ?", array(1), true)->nbre;
    }



}
