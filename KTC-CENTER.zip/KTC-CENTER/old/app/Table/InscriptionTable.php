<?php


    namespace App\Table;
    use Core\Table\Table;
/**
 * Created by PhpStorm.
 * User: ppeyton
 * Date: 18/03/2017
 * Time: 22:28
 */
class InscriptionTable extends Table{

        public function getModule($id){
            return $this->query("SELECT idmodule, nom_module FROM formation_module
                                  INNER JOIN module ON module_idmodule = idmodule
                                  INNER JOIN formation on formation_idformation = idformation
                                  AND idformation = ?
                                  AND formation.lisible = ?
                                  AND module.lisible = ?
                                  AND formation_module.lisible = ?",
                                  array($id, 1, 1, 1));
        }
        public function getFormation($val){
            return $this->query("SELECT idformation, nom_formation FROM formation
                                  INNER JOIN formation_type ON formation_type_idformation_type = idformation_type
                                  AND type = ?
                                  AND formation.lisible = ?
                                  AND formation_type.lisible = ?",
                                  array($val, 1, 1));
        }

    public function selection_vu(){
        $liste_vu = array();
        foreach( $this->query("SELECT etudiant_idetudiant FROM inscription WHERE lisible = ?", array(1)) as $ide){
            array_push($liste_vu, $ide->etudiant_idetudiant);
        }
      return $liste_vu;
    }
    public function modules($id){
        $modules = array();
        $liste = $this->query("SELECT liste_module FROM inscription WHERE lisible = ? AND etudiant_idetudiant = ?",
                array(1, $id), true)->liste_module;
        $liste = explode(',', $liste);
        foreach($liste as $l){
            $m = $this->query("SELECT * FROM module WHERE lisible = ? AND idmodule = ?", array(1, $l), true);
            array_push($modules, $m);
        }
        return $modules;
    }

}