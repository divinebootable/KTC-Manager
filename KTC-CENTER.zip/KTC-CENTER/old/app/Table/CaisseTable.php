<?php


namespace App\Table;
use Core\Table\Table;
/**
 * Created by PhpStorm.
 * User: ppeyton
 * Date: 18/03/2017
 * Time: 22:28
 */
class CaisseTable extends Table
{
    public function all(){
        return $this->query("SELECT nom, prenom, idcaisse, nom_formation, cout_formation, type, matricule, sum(montant) as versement, caisse.date_save as date_save FROM caisse
                                INNER JOIN formation_etudiant ON formation_etudiant.idformation_etudiant = caisse.formation_etudiant_idformation_etudiant
                                INNER JOIN formation ON formation.idformation = formation_etudiant.formation_idformation
                                INNER JOIN formation_type ON formation_type.idformation_type = formation.formation_type_idformation_type
                                INNER JOIN etudiant ON etudiant.idetudiant = formation_etudiant.etudiant_idetudiant
                                INNER JOIN personne ON personne.idpersonne = etudiant.personne_idpersonne
                                AND caisse.lisible = ?
                                AND formation_etudiant.lisible = ?
                                AND formation.lisible = ?
                                AND formation_type.lisible = ?
                                AND etudiant.lisible = ?
                                AND personne.lisible = ?
                                GROUP BY matricule", array(1, 1, 1, 1, 1, 1));
    }

    public function formations($idetudiant){
        return $this->query("SELECT idformation_etudiant, nom_formation, type FROM formation_etudiant
                                  INNER JOIN formation ON formation.idformation = formation_etudiant.formation_idformation
                                  INNER JOIN etudiant ON etudiant.idetudiant = formation_etudiant.etudiant_idetudiant
                                  INNER JOIN formation_type ON formation_type.idformation_type = formation.formation_type_idformation_type
                                  AND etudiant.lisible = ?
                                  AND formation.lisible = ?
                                  AND formation_etudiant.lisible = ?
                                  AND formation_type.lisible = ?
                                  AND etudiant.idetudiant = ?", array(1, 1, 1, 1, $idetudiant));
    }

    public function historique_paiement($id){
        return $this->query("SELECT montant, caisse.date_save as date_save FROM caisse
                                    INNER JOIN formation_etudiant ON  formation_etudiant.idformation_etudiant = caisse.formation_etudiant_idformation_etudiant
                                    AND caisse.lisible = ?
                                    AND formation_etudiant.lisible = ?
                                    AND formation_etudiant.idformation_etudiant = ?", array(1, 1, $id));
    }

    public function recap_paiement($id){
        $val = $this->query("SELECT cout_formation FROM formation_etudiant
                                    INNER JOIN formation ON  formation.idformation = formation_etudiant.formation_idformation
                                    AND formation.lisible = ?
                                    AND formation_etudiant.lisible = ?
                                    AND formation_etudiant.idformation_etudiant = ?", array(1, 1, $id));

        return $val;
    }

    public function montant($id){

        $val = $this->query("SELECT sum(montant) as montant FROM caisse
                                WHERE formation_etudiant_idformation_etudiant = ?
                                AND caisse.lisible = ?", array($id, 1));

        return $val->montant;
    }



}