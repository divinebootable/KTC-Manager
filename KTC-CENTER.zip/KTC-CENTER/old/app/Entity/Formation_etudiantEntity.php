<?php
    namespace App\Entity;
    use \Core\Entity\Entity;
    class Formation_etudiantEntity extends  Entity{


    }
?>