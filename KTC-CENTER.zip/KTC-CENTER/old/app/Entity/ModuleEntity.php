<?php
    namespace App\Entity;
    use \Core\Entity\Entity;

    class ModuleEntity extends Entity{

        public function getUrl(){
            return "?p=module.show&id=".$this->idmodule;
        }

        public function getModifier(){
            return "?p=module.modifier&id=".$this->idmodule;
        }
        public function getSupprimer(){
            return "?p=module.supprimer&id=".$this->idmodule;
        }

    }
?>