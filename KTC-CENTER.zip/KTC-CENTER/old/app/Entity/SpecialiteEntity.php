<?php
    namespace App\Entity;
    use \Core\Entity\Entity;
    class SpecialiteEntity extends  Entity{

        public function getModifier(){
            return "?p=specialite.modifier&id=".$this->idspecialite;
        }
        public function getSupprimer(){
            return "?p=specialite.supprimer&id=".$this->idspecialite;
        }
    }
?>