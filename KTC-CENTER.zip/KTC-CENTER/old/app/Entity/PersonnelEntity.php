<?php
    namespace App\Entity;
    use \Core\Entity\Entity;
    class PersonnelEntity extends  Entity{

    }
?>