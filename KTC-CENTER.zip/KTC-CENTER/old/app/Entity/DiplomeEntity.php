<?php
    namespace App\Entity;
    use \Core\Entity\Entity;
    class DiplomeEntity extends  Entity{

       public function getModifier(){
            return "?p=diplome.modifier&id=".$this->iddiplome;
        }
        public function getSupprimer(){
            return "?p=diplome.supprimer&id=".$this->iddiplome;
        }
    }
?>