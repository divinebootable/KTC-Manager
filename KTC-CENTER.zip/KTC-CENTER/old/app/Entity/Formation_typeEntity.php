<?php
namespace App\Entity;
use \Core\Entity\Entity;
class Formation_typeEntity extends  Entity{

    public function getUrl(){
        return "?p=formation_type.show&id=".$this->idformation_type;
    }
    public function getModifier(){
        return "?p=formation_type.modifier&id=".$this->idformation_type;
    }
    public function getSupprimer(){
        return "?p=formation_type.supprimer&id=".$this->idformation_type;
    }

}
?>