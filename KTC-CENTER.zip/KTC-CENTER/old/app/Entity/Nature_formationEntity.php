<?php
    namespace App\Entity;
    use \Core\Entity\Entity;
    class Nature_formationEntity extends  Entity{

        public function getModifier(){
            return "?p=nature_formation.modifier&id=".$this->idnature_formation;
        }
        public function getSupprimer(){
            return "?p=nature_formation.supprimer&id=".$this->idnature_formation;
        }
    }
?>