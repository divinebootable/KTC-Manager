<?php
    namespace App\Entity;
    use \Core\Entity\Entity;
    class CaisseEntity extends  Entity{

        public function getModifier(){
            return "?p=caisse.modifier&id=".$this->idcaisse;
        }
        public function getSupprimer(){
            return "?p=caisse.supprimer&id=".$this->idcaisse;
        }
        public function getImprimer(){
            return "?p=caisse.supprimer&id=".$this->idcaisse;
        }
    }
?>