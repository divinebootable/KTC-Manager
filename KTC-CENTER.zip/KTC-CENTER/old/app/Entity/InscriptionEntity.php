<?php
/**
 * Created by PhpStorm.
 * User: LE-POLY
 * Date: 4/11/17
 * Time: 1:24 PM
 */


namespace App\Entity;
use \Core\Entity\Entity;
class InscriptionEntity extends  Entity{


}

?>
