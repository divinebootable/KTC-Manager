<?php
    namespace App\Entity;
    use \Core\Entity\Entity;
    class NoteEntity extends  Entity{

        public function getModifier(){
            return "?p=note.modifier&id=".$this->idnote;
        }
        public function getSupprimer(){
            return "?p=note.supprimer&id=".$this->idnote;
        }
    }
?>