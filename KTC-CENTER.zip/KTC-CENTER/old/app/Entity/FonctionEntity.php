<?php
    namespace App\Entity;
    use \Core\Entity\Entity;
    class FonctionEntity extends  Entity{

        public function getModifier(){
            return "?p=fonction.modifier&id=".$this->idfonction;
        }
        public function getSupprimer(){
            return "?p=fonction.supprimer&id=".$this->idfonction;
        }
    }
?>