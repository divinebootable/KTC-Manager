<?php
    namespace App\Entity;
    use \Core\Entity\Entity;
    class Secteur_activiteEntity extends Entity{

        public function getModifier(){
            return "?p=secteur_activite.modifier&id=".$this->idsecteur_activite;
        }
        public function getSupprimer(){
            return "?p=secteur_activite.supprimer&id=".$this->idsecteur_activite;
        }
    }
?>