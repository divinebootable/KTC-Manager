<?php
    namespace App\Entity;
    use \Core\Entity\Entity;
    class FormationEntity extends  Entity{

        public function getUrl(){
            return "?p=formation.show&id=".$this->idformation;
        }
        public function getModifier(){
            return "?p=formation.modifier&id=".$this->idformation;
        }
        public function getSupprimer(){
            return "?p=formation.supprimer&id=".$this->idformation;
        }

        public function getDate_inscription(){
            $datefr =  \DateTime::createFromFormat('Y-m-d', $this->date_etudiant);
            $dateainserer =  $datefr ? $datefr->format('d/m/Y') : date('d/m/Y');
            return $dateainserer;
        }
        public function getDate_module(){
            $datefr =  \DateTime::createFromFormat('Y-m-d', $this->date_module);
            $dateainserer =  $datefr ? $datefr->format('d/m/Y') : date('d/m/Y');
            return $dateainserer;
        }

        public function getAfficher_etudiant()
        {
            return "?p=etudiant.show&id=" . $this->idetudiant;
        }
        public function getAfficher_module()
        {
            return "?p=module.show&id=".$this->idmodule;
        }

        public function getAfficherType(){
            return "?p=formation_type.show&id=".$this->idformation_type;
        }

        public function getMes_modules(){
            return \App::getInstance()->getTable('Inscription')->modules($this->idetudiant);
        }
    }
?>