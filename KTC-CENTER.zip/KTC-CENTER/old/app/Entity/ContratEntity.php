<?php
    namespace App\Entity;
    use \Core\Entity\Entity;
    class ContratEntity extends  Entity{

        public function getModifier(){
            return "?p=contrat.modifier&id=".$this->idcontrat;
        }
        public function getSupprimer(){
            return "?p=contrat.supprimer&id=".$this->idcontrat;
        }
    }
?>