<?php
    namespace App\Entity;
    use \Core\Entity\Entity;
    class DroitEntity extends  Entity{

    }
?>