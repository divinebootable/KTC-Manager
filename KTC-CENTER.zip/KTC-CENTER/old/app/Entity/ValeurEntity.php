<?php
    namespace App\Entity;
    use \Core\Entity\Entity;
    class ValeurEntity extends  Entity{

        public function getModifier(){
            return "?p=valeur.modifier&id=".$this->idvaleur;
        }
        public function getSupprimer(){
            return "?p=valeur.supprimer&id=".$this->idvaleur;
        }
    }
?>