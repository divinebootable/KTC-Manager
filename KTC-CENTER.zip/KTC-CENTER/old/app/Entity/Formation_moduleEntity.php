<?php
    namespace App\Entity;
    use \Core\Entity\Entity;

    class Formation_moduleEntity extends Entity{

    }
?>