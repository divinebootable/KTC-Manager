<?php
    namespace App\Entity;
    use \Core\Entity\Entity;
    class Branche_activiteEntity extends  Entity{

        public function getModifier(){
            return "?p=branche_activite.modifier&id=".$this->idbranche_activite;
        }
        public function getSupprimer(){
            return "?p=branche_activite.supprimer&id=".$this->idbranche_activite;
        }
    }
?>