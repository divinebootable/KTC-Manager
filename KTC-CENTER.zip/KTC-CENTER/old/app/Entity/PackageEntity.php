<?php
    namespace App\Entity;
    use \Core\Entity\Entity;
    class PackageEntity extends  Entity{

        public function getDroits(){
            return \App::getInstance()->getTable('Droit')->droits($this->idpackage);
        }
    }
?>