<?php
/**
 * Created by PhpStorm.
 * User: LE-POLY
 * Date: 4/11/17
 * Time: 1:24 PM
 */


namespace App\Entity;
use \Core\Entity\Entity;
class EtudiantEntity extends  Entity
{

    public function getUrl()
    {
        return "?p=etudiant.show&id=" . $this->idetudiant;
    }

    /*  public function getType(){
         $id = $this->formation_type_idformation_type;
         $data = array('idformation_type'=>$id, 'lisible'=>1);
         $formation_type =  \App::getInstance()->getTable("formation_type")->find($data);
         if($formation_type){
             return $formation_type;
         }else{
             $data = array('type'=>'DEFAUT', 'lisible'=>1);
             return \App::getInstance()->getTable("formation_type")->find($data);
         }
     }*/

    public function getModifier()
    {
        return "?p=etudiant.modifier&id=" . $this->idetudiant;
    }

    public function getSupprimer()
    {
        return "?p=etudiant.supprimer&id=" . $this->idetudiant;
    }

    public function getFormation_url()
    {
        return "?p=formation.show&id=" . $this->idformation;
    }

    public function getDate_naissanceFR(){

        return \App::getInstance()->getDateFR($this->date_naissance);
    }
    public function getActiver(){
        return "?p=etudiant.activer&id=".$this->idetudiant;
    }
    public function getDesactiver(){
        return "?p=etudiant.desactiver&id=".$this->idetudiant;
    }



}

?>
