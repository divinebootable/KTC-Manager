<?php
    namespace App\Entity;
    use \Core\Entity\Entity;
    class FiliereEntity extends  Entity{

        public function getModifier(){
            return "?p=filiere.modifier&id=".$this->idfiliere;
        }
        public function getSupprimer(){
            return "?p=filiere.supprimer&id=".$this->idfiliere ;
        }
    }
?>