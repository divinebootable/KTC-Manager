<?php
    namespace App\Entity;
    use \Core\Entity\Entity;
    class EvaluationEntity extends  Entity{

        public function getModifier(){
            return "?p=evaluation.modifier&id=".$this->idevaluation;
        }
        public function getSupprimer(){
            return "?p=evaluation.supprimer&id=".$this->idevaluation;
        }

    }
?>