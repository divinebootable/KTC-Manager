<?php
    namespace App\Entity;
    use \Core\Entity\Entity;
    class EnseignantEntity extends  Entity{

        public function getUrl(){
            return "?p=enseignant.show&id=".$this->idenseignant;
        }

       public function getModifier(){
            return "?p=enseignant.modifier&id=".$this->idenseignant;
        }
        public function getSupprimer(){
            return "?p=enseignant.supprimer&id=".$this->idenseignant;
        }

        public function getDate_naissanceFR(){
            return \App::getDateFR($this->date_naissance);
        }
        public function getDate_debutFR(){
            return \App::getDateFR($this->date_debut);
        }
    }
?>