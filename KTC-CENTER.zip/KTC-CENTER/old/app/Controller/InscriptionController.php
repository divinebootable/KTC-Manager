<?php
namespace App\Controller;
use \App;
class InscriptionController extends AppController{
    public function __construct(){
        $this->loadModel('Personne');
        $this->loadModel('Diplome');
        $this->loadModel('Etudiant');
        $this->loadModel('Formation_etudiant');
        $this->loadModel('Inscription');
        $this->loadModel('Formation');

    }
    private $action;
    public function nouveau(){
        $errors = false;
        $message = "";
        $personne = array('nom'=>'', 'prenom'=>'', 'date_naissance'=>'', 'telephone'=>'', 'email'=>'');
        $etudiant = array('matricule'=>'', 'dernier_diplome'=>'', 'personne_idpersonne'=>'');
        $formations=$this->Inscription->getFormation("DQP");
        if($_POST){
            $data1 = array('nom'=>$_POST['nom'], 'prenom'=>$_POST['prenom'],
                'date_naissance'=>$this->getDateSQL($_POST['date_naissance']),
                'telephone'=>$_POST['telephone'], 'email'=>$_POST['email'],
                'sexe'=>$_POST['sexe']);

            if($this->Personne->find(array('email'=>$_POST['email'], 'lisible'=>1))){
                $errors = true;
                $message = "Cette adresse email existe déja!";
                $personne = $data1;
            }else{
                $pers = array('nom'=>$_POST['nom'], 'prenom'=>$_POST['prenom'],
                    'date_naissance'=>$this->getDateSQL($_POST['date_naissance']),
                    'telephone'=>$_POST['telephone'],
                    'sexe'=>$_POST['sexe'], 'lisible'=>1);
                if($this->Personne->find($pers)){
                    $errors = true;
                    $message = "Cet étudiant a déja été enrégistré!";
                    $personne = $data1;
                }else{
                    if($this->Personne->insert($data1)){
                        $id_last =  $this->Personne->selection(array('LAST_INSERT_ID() as last') , array('lisible'=>1), true)->last;
                        $data2=array('matricule'=>$this->getCode($_POST['date_naissance'], $_POST['sexe']), 'diplome_iddiplome'=>$_POST['diplome_iddiplome'], 'personne_idpersonne'=>$id_last);

                        if($this->Etudiant->insert($data2)){
                            $id_last2 =  $this->Etudiant->selection(array('LAST_INSERT_ID() as last') , array('lisible'=>1), true)->last;
                            $etudiant=$data2;
                            /*$liste_modules =  implode(',', $_POST['module_idmodule']);
                            $inscription = array('code'=>uniqid(), 'etudiant_idetudiant'=>$id_last2, 'liste_module'=>$liste_modules);

                            $this->Inscription->insert($inscription);*/
                            $data3=array('formation_idformation'=>$_POST['formation_idformation'], 'etudiant_idetudiant'=>$id_last2);
                            $this->Formation_etudiant->insert($data3);
                            $this->sendMail($_POST['nom'], $_POST['prenom'], $_POST['email'], $_POST['telephone'],
                                $_POST['formation_idformation']);

                            $errors = false;
                          //  $this->impression('liste_etudiants');
                            $message = "Etudiant enrégistré avec succès! Un mail a été envoyé à votre adresse, bien vouloir le consulter pour plus d'informations.";
                        }else{
                            $errors = true;
                            $message = "Erreur lors de l'enrégistrement de l'étudiant! Veuillez contacter l'administrateur";
                            $personne = $data1;
                        }
                    }else{
                        $errors = true;
                        $message = "Erreur lors de l'enrégistrement de l'étudiant! Veuillez contacter l'administrateur";
                        $personne = $data1;
                    }
                }
            }
        }
        $diplomes = $this->Diplome->all();
        $this->render_inscription('inscription.nouveau', compact('etudiant', 'personne', 'formations', 'diplomes', 'errors', 'message'));
    }

  

    /*public function load(){
        $idformation = $_GET['id'];
        $modules = $this->Inscription->getModule($idformation);
        $this->render_inscription_local('inscription.load', compact('modules'));
    }*/

    public function rechercher(){
    
   /*     $this->act = $_GET['action'];
        $action = $this->act;
        $exist = true;
        if($_POST){
            if($action == 'modifier'){
                $this->modifier($_POST['code']);
            }else if($action== 'imprimer'){
                $this->imprimer($_POST['code']);
            }else{
                $this->nouveau();
            }
        }else{
            $this->render_inscription('inscription.rechercher', compact('action', 'exist'));
        }*/

    }
private function sendMail($nom, $prenom, $email, $telephone,  $idformation){
        $etudiant = $nom.' '.$prenom;
        $nom_formation = $this->Formation->selection(array('nom_formation as nom_formation'), array('idformation'=>$idformation,'lisible'=>1), true)->nom_formation;
        
        $sujet = "INSCRIPTION DQP 2018";
        $header = "From: ".$etudiant." <".$email.">\r\n";
        $header .= "Content-Type: text/html; charset=\"UTF-8\"\r\n";
    
    $header2 = "From: KTC Center<info@kamer-center.net>\r\n";
        $header2 .= "Content-Type: text/html; charset=\"UTF-8\"\r\n";


        try{
            $sms = "<html><body>";
            $sms .= "Bonjour<br>";
            $sms .= 'Je suis <b>'.$etudiant.'</b> repondant au numéro <b>'.$telephone.'</b> désirant suivre la formation <b>'.$nom_formation.'</b>';
            $sms .= "</body></html>";

        $reponse = "<html><body>";
            $reponse .= 'Bonjour Monsieur/Madamme <b>'.$etudiant.'</b><br>';
            $reponse .= 'Merci pour votre inscription. Vos informations ont été bien reçues et transmises au Services des Formations.<br>';
            $reponse .= 'Vos informations sont les suivantes:<br>';   
        $reponse .= '--> Noms et prénoms: <b>'.$etudiant.'</b><br>';
        $reponse .= '--> Formation solicitée: <b>'.$nom_formation.'</b><br>';
            $reponse .= 'Merci de nous <a href="http://www.kamer-center.net/contact">contacter</a> pout toute modification.<br>';
        $reponse .= '<u>NB</u>:<em>Seul le payement des frais d\'inscription vous garantit la place pour la formation choisie.</em><br><br>';
            $reponse .= 'Cordialement,<br>';    
            $reponse .= 'L\'Equipe de KTC Center,<br>'; 
            $reponse .= 'http://www.kamer-center.net';      
            $reponse .= "</body></html>";
    
            mail('info@kamer-center.net', $sujet, $sms, $header);
            mail($email, 'KTC Center: Inscription aux vacances utiles en informatique', $reponse, $header2);
        }catch(Exception $ex){
            header('500 Internal Server Error', true, 500);
            die('Erreur '.$ex->getline().': Veuillez contacter l\'administrateur');
        }
    }
    public function imprimer(){

    }


    private function getCode($data, $sexe){
        $nbre = $this->Etudiant->getNombre();
        $date = date_parse($data);
       $annee = $date['year'];
       $an = substr($annee, 2, 2);
        $code = "";
        if($nbre<10){
            $code = "00".$nbre;
        }elseif ($nbre<100 and $nbre>=10) {
            $code = "0".$nbre;
        }elseif ($nbre>=100) {
            $code = $nbre;
        }
        $sexe = $sexe == 'MASCULIN' ? 'M' : 'F';
        $matricule = date('y').$sexe.$an.$code;
        return $matricule;
    }
}
?>