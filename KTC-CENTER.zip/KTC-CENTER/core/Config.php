<?php
/**
 * Created by PhpStorm.
 * User: ppeyton
 * Date: 22/02/2017
 * Time: 00:23
 */

namespace Core;


class Config
{
    private $settings = array();

    private static $_instance;
    private $id;

    public static function getInstance($file){

        if(is_null(self::$_instance)){

            self::$_instance = new Config($file);
        }

        return self::$_instance;
    }

    public function __construct($file){

        $this->settings = require($file);
    }

    public function get($key){

        if(!isset($this->settings[$key])){

            return null;
        }

        return $this->settings[$key];
    }
}
?>
