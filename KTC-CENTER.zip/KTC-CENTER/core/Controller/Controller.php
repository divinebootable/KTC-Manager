<?php
    namespace Core\Controller;
    use Core\Report\Imprimer;

    class Controller{

        protected $viewPath;
        protected $template;

        protected function render($view, $variables=array()){
            $current_user = isset($_SESSION['auth']) ? \App::getInstance()->getTable('Utilisateur')->getUser($_SESSION['auth']) : "";
            compact('current_user');
            ob_start();
            extract($variables);
            require($this->viewPath.str_replace('.', '/', $view).'.php');
            $content = ob_get_clean();
           require($this->viewPath.$this->template.'.php');
        }

        protected function render_inscription($view, $variables=array()){
            $chemin = ROOT.'/app/Views/';
            $chemin = str_replace('\\', '/', $chemin);
            ob_start();
            extract($variables);
            require($chemin.str_replace('.', '/', $view).'.php');
            $content_inscription = ob_get_clean();
           require($chemin.'inscription/default.php');
        }
        protected function render_inscription_local($view, $variables = array()){
            $chemin = ROOT.'/app/Views/';
            $chemin = str_replace('\\', '/', $chemin);
            ob_start();
            extract($variables);
            require($chemin.str_replace('.', '/', $view).'.php');
            $content_inscription_ajax = ob_get_clean();
            require($chemin.'inscription/default_inscription.php');
        }
        protected function render_ajax($view, $variables = array()){
            ob_start();
            extract($variables);
            require_once($this->viewPath.'css.php');
            require_once($this->viewPath.str_replace('.', '/', $view).'.php');
            $content_ajax = ob_get_clean();
            require_once($this->viewPath.'default_ajax.php');
            require_once($this->viewPath.'ajax.php');
        }

        protected function render_ajax_local($view, $variables = array()){
            ob_start();
            extract($variables);
            require_once($this->viewPath.str_replace('.', '/', $view).'.php');
             $content_ajax = ob_get_clean();
            require_once($this->viewPath.'default_ajax.php');
            require_once($this->viewPath.'ajax_local.php');

        }


        protected function forbidden(){
            header('Location:index.php?p=login');
            //header('Location:index.php?p=verrouiller');
        }

        protected function verouiller(){
            header('Location:index.php?p=verrouiller');
        }

        public function getDateFR($dateDeTonPost){
            $datefr =  \DateTime::createFromFormat('Y-m-d', $dateDeTonPost);
            $tadateainserer =  $datefr ? $datefr->format('d/m/Y') : date('d/m/Y');
            return $tadateainserer;
        }
        public function getDateSQL($dateDeTonPost){
            $datefr =  \DateTime::createFromFormat('d/m/Y', $dateDeTonPost);
            $tadateainserer =  $datefr ? $datefr->format('Y-m-d') : date('d/m/Y');
            return $tadateainserer;
        }

        protected function notFound(){
            header("HTTP/1.0 404 Not Found");
            $message = '
                  <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta http-equiv="X-UA-Compatible" content="IE=edge">
          <title>KTC-MANAGER| 404 Page not found</title>
          <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

          <link rel="stylesheet" href="../public/bootstrap/css/bootstrap.min.css">

          <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">

          <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">

          <link rel="stylesheet" href="../public/dist/css/AdminLTE.min.css">

          <link rel="stylesheet" href="../public/dist/css/skins/_all-skins.min.css">


          <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>

        </head>
        <body class="hold-transition skin-blue sidebar-mini">
            <!-- Main content -->
            <section class="content">
              <div class="error-page">
                <h2 class="headline text-yellow"> 404</h2>

                <div class="error-content">
                  <h3><i class="fa fa-warning text-yellow"></i> Oops! Page Introuvable.</h3>

                  <p>
                    Cette page est introuvable,
                    Vous pouvez <a href="?p=home">retourner � l\'accueil</a>   </p>


                </div>

              </div>

            </section>

          <footer class="main-footer">
            <div class="pull-right hidden-xs">
              <b>Version</b> 2.3.8
            </div>
            <strong>Copyright &copy; 2017 <a href="http://www.kamer-center.net" target="_blank">KTC-CENTER</a>.</strong> All rights
            reserved.
          </footer>

          <div class="control-sidebar-bg"></div>
        </div>
        <script src="../public/plugins/jQuery/jquery-2.2.3.min.js"></script>

        <script src="../public/bootstrap/js/bootstrap.min.js"></script>

        <script src="../public/plugins/fastclick/fastclick.js"></script>

        <script src="../public/dist/js/app.min.js"></script>

        <script src="../public/dist/js/demo.js"></script>
        </body>
        </html>';

            die($message);
        }
    }
?>