<?php

namespace Core\Table;
use \Core\Database\Database;

class Table
{
    protected $table;
    protected $db;

    public function __construct(Database $db){
        $this->db = $db;
        if(is_null($this->table)) {
            $parts = explode('\\', get_class($this));
            $class_name = end($parts);
            $this->table = strtolower(str_replace('Table', '', $class_name));
        }
    }

    public function query($statement, $attributes=null, $one=false){

        if($attributes){
            return $this->db->prepare($statement, $attributes, str_replace('Table', 'Entity', get_class($this)), $one);
        }else{
            return $this->db->select($statement,  str_replace('Table', 'Entity', get_class($this)), $one);
        }
    }
    public function all(){
        return $this->query("SELECT * FROM {$this->table} WHERE lisible = ?", array(1));
    }

    public function find2($id){
        return $this->query("SELECT * FROM {$this->table} WHERE id$this->table = ? AND lisible=?", array($id, 1), true);
    }

    public function selection($element, $data, $one=false){
        $part_query = array();
        $attributes = array();
        foreach($data as $k => $v){
            $part_query[] = "$k = ?";
            $attributes[] = $v;
        }
        $part = implode(' AND ', $part_query);
        $element = implode(', ', $element);
       //var_dump("SELECT $element FROM {$this->table} WHERE $part", $attributes);
     return $this->query("SELECT $element FROM {$this->table} WHERE $part", $attributes, $one);
    }

    public function find($data){
        $part_query = array();
        $attributes = array();
        foreach($data as $k => $v){
            $part_query[] = "$k = ?";
            $attributes[] = $v;
        }
        $part = implode(' AND ', $part_query);
       // var_dump("SELECT * FROM {$this->table} WHERE $part");
        return $this->query("SELECT * FROM {$this->table} WHERE $part", $attributes, true);
    }


    public function update($id, $fields){
        $query_part = array();

        $attributes = array();

        foreach($fields as $k => $v){
            $query_part[] = "$k = ?";
            $attributes[] = $v;
        }
        $attributes[] = $id;
        $part = implode(',', $query_part);
        $s = "UPDATE {$this->table} SET $part WHERE id$this->table = ?";
      //  var_dump($s, $attributes);
       return $this->query($s, $attributes, true);
    }

    public function insert($fields){
        $query_part = array();
        $values = array();
        $attributes = array();
        foreach($fields as $k => $v){
            $query_part[] = "$k";
            $values[] = "?";
            $attributes[] = $v;
        }
        array_push($query_part, 'date_save');
        array_push($values, '?');
        array_push($attributes, date('Y-m-d'));

        $part = implode(',', $query_part);
        $val = implode(',', $values);
       // var_dump($attributes);
        return $this->query("INSERT INTO {$this->table}($part)  VALUES($val)", $attributes, true);
    }

    public function delete($fields){
        $query_part = array();
        $attributes = array();
        foreach($fields as $k => $v){
            $query_part[] = "$k = ?";
            $attributes[] = $v;
        }
        $part = implode(' AND ', $query_part);
        //var_dump("DELETE FROM {$this->table} WHERE $part", $attributes);
        return $this->query("DELETE FROM {$this->table} WHERE $part", $attributes, true);
    }
}