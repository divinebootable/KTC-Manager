<?php

/**
 * Created by PhpStorm.
 * User: ppeyton
 * Date: 18/04/2017
 * Time: 20:23
 */
    namespace Core\Report;
class Imprimer
{

    protected function impression($file, $parametres=array()){
        $db = "jdbc:mysql://localhost/ktcmanager?user=paroisse&password=paroisse#2016";
        set_time_limit(60);
        echo("ici 1 ");
        define('JAVA_INC_URL', 'http://localhost:8081/JavaBridge/java/Java.inc');
        include(JAVA_INC_URL);
        echo("ici 2");
       $System = new Java('Java.lang.System');
        echo("ici 3");
        $class = new JavaClass("java.lang.Class");
        $class->forName("com.mysql.jdbc.Driver");
       $driverManager = new JavaClass("java.sql.DriverManager");
        $conn = $driverManager->getConnection($db);
        //compilation
        $compileManager = new JavaClass("net.sf.jasperreports.engine.JasperCompileManager");
        $viewer = new JavaClass("net.sf.jasperreports.view.JasperViewer");
        $report = $compileManager->compileReport(realpath(".")."/".$file.".jrxml");
        //fill
        $fillManager = new JavaClass("net.sf.jasperreports.engine.JasperFillManager");
        $params = new Java("java.util.HashMap");
        $emptyDataSource = new Java("net.sf.jasperreports.engine.JREmptyDataSource");
        if(!empty($parametres)){
            foreach($this->parametres as $k=>$val){
                $params->put($k,  $val);            }
        }
        $jasperPrint = $fillManager->fillReport($report, $params, $conn);
        $exportManager = new JavaClass("net.sf.jasperreports.engine.JasperExportManager");
        $outputPath = realpath(".")."/".$this->file.".pdf";
        $exportManager->exportReportToPdffile($jasperPrint, $outputPath);

        echo'<object style="width:100%; height:100%;" data="'.$file.'.pdf" type="text/html" codetype="application/pdf" ></object>
		 	';
    }


}