<?php

    namespace Core\HTML;
        class Form{
            /**
             * @var
             */
            private $data;
            public $surround = 'Div';

            /**
             * @param array $data
             */
            public function __construct($data=array()){
                $this->data = $data;
            }

            /**
             * @param $html
             * @return string
             */
            protected function surround($html){
                return "<$this->surround class=\"form-group\">{$html}</$this->surround>";
            }
            /**
             * @param $index
             * @return null
             */
            protected function getValue($index){
                if(is_object($this->data)) {
                    return $this->data->$index;
                }
                return !isset($this->data[$index]) ? $this->data[$index] : null;
            }


            /**
             * @param $name
             * @param $label
             * @param array $options
             * @return string
             */
            public function label($label, $class="", $id=""){
                return '<label class="'.$class.'" id="'.$id.'">'.$label.'</label>';
            }
            public function input($name, $class="", $id="",  $type='text', $required=''){

                if($type === 'textarea'){
                    $input = '<textarea class="'.$class.'" id="'.$id.'" name="'.$name.'" '.$required.'>'.$this->getValue($name).'"</textarea>';
                }else{

                    $input = '<input type="'.$type.'" class="'.$class.'" id="'.$id.'" value ="'.$this->getValue($name).'"  name="'.$name.' required">';
                }
                return  $this->surround($input);
            }


            /**
             * @return string
             */
            public function submit($name){
                return '<button type="submit" class="btn btn-primary pull-right">$name</button>';
            }


        }
?>