<?php

    namespace Core\Database;
    use \PDO;

    class MysqlDatabase extends Database{
        private $db_nom;
        private $db_user;
        private $db_pass;
        private $db_host;
        private $pdo;

        public function __construct($host, $nom, $user, $pass){
            $this->db_host = $host;
            $this->db_nom = $nom;
            $this->db_user = $user;
            $this->db_pass = $pass;
        }

        public function getPDO(){
            if($this->pdo === null){
                $pdo = new PDO("mysql:host=$this->db_host;dbname=$this->db_nom", "$this->db_user", "$this->db_pass");
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $this->pdo = $pdo;
            }
            return $this->pdo;
        }

        public function select($statement, $class_name=null, $one=false){
           $q = $this->getPDO()->query($statement);
            if($class_name === null){
                $q->setFetchMode(PDO::FETCH_OBJ);
            }else{
                $q->setFetchMode(PDO::FETCH_CLASS, $class_name);
            }
            if($one){
                $data = $q->fetch();
            }else{
                $data = $q->fetchAll();
            }
            return $data;
        }

        public function prepare($statement, $parametres, $class_name=null, $one = false){
            $req = $this->getPDO()->prepare($statement);
          //var_dump($req, $parametres);
           $resultat = $req->execute($parametres);
            if(
                strpos($statement, "UPDATE") === 0 ||
                strpos($statement, "INSERT") === 0 ||
                strpos($statement, "DELETE") === 0
            ){
                return $resultat;
            }else {
                if ($class_name === null) {
                    $req->setFetchMode(PDO::FETCH_OBJ);
                } else {
                    $req->setFetchMode(PDO::FETCH_CLASS, $class_name);
                }
                if ($one) {
                    $data = $req->fetch();
                } else {
                    $data = $req->fetchAll();
                }
               return $data;
            }
        }
    }
?>