 $('#choix_formation').change(function(e){
     var a = $(this).val();
     var url = '?p=formation_module.nouveau';
     // $('.loader').show();
     $('#afficher_module_formation').empty();
     $.ajax({
         url:url,
         data:'id='+a,
         success:function(json){
             $('#afficher_module_formation').html(json, function(){
                 $('.loader').hide();
             });
         }
     });
 });

 $('.afficher').click(function(e){
     $('.loader').show();
     e.preventDefault();
     url = $(this).attr('href');
     $('.content-wrapper').load(url, function(){
         $('.loader').hide();
     })
 });



 $('.form-delete').submit(function(e){
     e.preventDefault();
     var $form = $(this);
     var url = $form.attr('action');
     swal({
             title: "Voulez-vous vraiment supprimer cet élément?",
             text: "Cette opération est irreversible!",
             type: "warning",
             showCancelButton: true,
             confirmButtonColor: "#DD6B55",
             closeOnConfirm: false,
             confirmButtonText: "Oui, supprimer!",
             showLoaderOnConfirm: true
         },
         function(isConfirm){

             $.ajax({
                 url:url,
                 type:$form.attr('method'),
                 data:$form.serialize(),
                 success:function(json){
                     swal('Suppression!',
                         'effectuée avec succès',
                         'success'
                     );
                     $('.loader').show();
                     $('.content-wrapper').load(url, function(){
                         $('.loader').hide();
                     });
                 }
             });

         });
 });

 /*$('.form-add').submit(function(e){
     e.preventDefault();
     var $form = $(this);
     var url = $form.attr('action');
     // alert(url);
     $('.loader').show();
     $.ajax({
         url:url,
         type:$form.attr('method'),
         data:$form.serialize(),
         success:function(json){
             $('.content-wrapper').html(json, function(){
                 $('.loader').hide();
             });
         }
     });
 }); */
 //saisir les notes
 $('#evaluation_formation').on('change', function(){
     var id = $(this).val();
     $('#evaluation_module').empty();
     if(id != ''){
         $.ajax({
             url:'?p=evaluation.modules',
             data:'id='+id,
             dataType:'json',
             success:function(json){
                 $('#evaluation_etudiant_body').empty();
                 $('#evaluation_module').append('<option selected disabled>Selectionner un module</option>');
                 $.each(json , function(index, module){
                     $('#evaluation_module').append('<option value="'+module.idmodule+'">'+module.nom_module+'</option>');
                 });
             }
         });
     }
 });
 $('#evaluation_module').on('change', function(){
     var id = $(this).val();
     $('#evaluation_note').empty();
     if(id != ''){
         $.ajax({
             url:'?p=evaluation.notes',
             data:'id='+id,
             dataType:'json',
             success:function(json){
                 $('#evaluation_etudiant_body').empty();
                 $('#evaluation_note').append('<option selected disabled>Selectionner le type de note</option>');
                 $.each(json , function(index, note){
                     $('#evaluation_note').append('<option value="'+note.idnote+'">'+note.type_note+'</option>');
                 });
             }
         });
     }
 });

 $('#evaluation_note').on('change', function(){
     var idnote = $(this).val();
     var idformation = $('#evaluation_formation').val();
     var idmodule = $('#evaluation_module').val();

     // alert(idnote+' '+idformation+' '+idmodule);
     $('#evaluation_etudiant').empty();
     if (!(idnote != '' && idformation != '' && idmodule != '')) {
     } else {
         $.ajax({
             url: '?p=evaluation.etudiants',
             data: {'idformation': idformation, 'idmodule': idmodule, 'idnote': idnote},
             dataType: 'json',
             success: function (json) {
                 if(json == ""){
                     $('#div-btn-save-note').hide();
                     $('#etudiant-not-found').show();
                     $('#tableau_note').hide();
                 }else{
                     $('#etudiant-not-found').hide();
                     $('#div-btn-save-note').show();
                     $('#tableau_note').show();
                     $('#evaluation_etudiant_body').empty();
                     $.each(json, function (index, etudiant) {
                         index++;
                         $('#evaluation_etudiant_body').append(
                             '<tr>' +
                             '<td>' + index + '</td>' +
                             '<td><input type="hidden" name="idetudiant[]" value="' + etudiant.idetudiant + '">' + etudiant.matricule + '</td>' +
                             '<td>' + etudiant.nom + ' ' + etudiant.prenom + '</td>' +
                             '<td><input type="text" placeholder="00.00" pattern="[0-9]{1}\.[0-9]{2}|1[0-9]{1}\.[0-9]{2}|20\.00" class="form-control" name="moyenne[]" required></td>' +
                             '</tr>'
                         );
                     });
                 }


             }
         });
     }
 });

 //consulter les notes

 $('#evaluation_formation_consulter').on('change', function(){
     var id = $(this).val();
     if(id != ''){
         $.ajax({
             url:'?p=evaluation.modules',
             data:'id='+id,
             dataType:'json',
             success:function(json){
                 $('loader').show();
                 $('#evaluation_module_consulter').empty();
                 $('#evaluation_note_consulter').empty();
                 $('#tableau_note_consulter').empty();
                 $('#evaluation_module_consulter').append('<option selected disabled>Selectionner un module</option>');
                 $.each(json , function(index, module){
                     $('#evaluation_module_consulter').append('<option value="'+module.idmodule+'">'+module.nom_module+'</option>');
                 });
                 $('loader').hide();
             }
         });
     }
 });
 $('#evaluation_module_consulter').on('change', function(){
     var id = $(this).val();
     $('#liste_note_consulter').empty();
     if(id != ''){
         $.ajax({
             url:'?p=evaluation.notes_consulter',
             data:'id='+id,
             dataType:'json',
             success:function(json){
                 $('loader').show();
                 $('#tableau_note_consulter').empty();
                 $('#evaluation_note_consulter').empty();
                 $('#evaluation_note_consulter').append('<option selected disabled>Selectionner le type de note</option>');
                 $.each(json , function(index, note){
                     $('#evaluation_note_consulter').append('<option value="'+note.idnote+'">'+note.type_note+'</option>');
                 });
                 $('loader').hide();
             }
         });
     }
 });

 $('#evaluation_note_consulter').on('change', function(){
     var idnote = $(this).val();
     var idformation = $('#evaluation_formation_consulter').val();
     var idmodule = $('#evaluation_module_consulter').val();


     if (!(idnote != '' && idformation != '' && idmodule != '')) {
     } else {
         $('#tableau_note_consulter').empty();
         $.ajax({
             url: '?p=evaluation.etudiants_consulter',
             data: {'idformation': idformation, 'idmodule': idmodule, 'idnote': idnote},
             success:function(json){
                 $('#tableau_note_consulter').html(json, function(){
                     $('.loader').hide();
                 });
             }
         });
     }
 });

 //ajouter droit


 $('.datepicker').datepicker({
     autoclose: true,
     language: 'fr'
 });

 $('.editer-droit input[type="checkbox"]').click(function () {
     $('.loader').show();
     var idD = $(this).val();
     var valeur;

     if (this.checked) { // si 'checkAll' est coché
         valeur = 1;
     } else { // si on décoche 'checkAll'
         valeur = 0;
     }

     var url = "?p=role.editer";
     $.ajax({
         url: url,
         data: {'id': idD, 'operation': valeur},
         success: function (json) {
          $('.loader').hide();
         }
     });
 });

 //click sur le bouton modifier le mot de passe dans modifier utilisateur

 $('#btn_modifier_password').click(function(){
     var $btn = $(this);
     var text = $btn.text();
     if(text == 'Annuler Modifier mot de passe'){
         $btn.text('Modifier le mot de passe');
         $btn.removeClass('btn-default');
         $btn.addClass('btn-warning');
         $('#form_modifier_password').hide();
         $('#form_modifier_password :input').attr('disabled', 'true');
     }else{
         $btn.text('Annuler Modifier mot de passe');
         $btn.removeClass('btn-warning');
         $btn.addClass('btn-default');
         $('#form_modifier_password').show();
         $('#form_modifier_password :input').removeAttr('disabled');
     }


 })

 //choix "tudiant pour reglèment
 $('#choix-etudiant-inscription').on('change', function(){
     var id = $(this).val();
     $('#choix-formation-inscription').empty();
     $('#historique-paiement').hide();
     if(id != ''){
         $.ajax({
             url:'?p=caisse.formations',
             data:'id='+id,
             dataType:'json',
             success:function(json){
                 $('#choix-formation-inscription').empty();
                 $('#choix-formation-inscription').append('<option selected disabled>Sélectionner une formation</option>');
                 $.each(json , function(index, formation){
                     $('#choix-formation-inscription').append('<option value="'+formation.idformation_etudiant+'">'
                                                                    +formation.type+': '+formation.nom_formation+
                                                              '</option>');
                 });
             }
         });
     }
 });

 //choix formation pour règlement

 var cout_formation = 0;
 var somme_versee = 0
 var balance = 0

 $('#choix-formation-inscription').on('change', function(){
     var id = $(this).val();
     $('#historique-table-body').empty();
     $('#historique-paiement').hide();
     if(id != ''){
         $.ajax({
            url:'?p=caisse.historique_paiement',
            data:'id='+id,
            dataType:'json',
            success:function(json){
                $('#historique-table-body').empty();

                $.each(json, function(index, caisse){
                    index++;

                    somme_versee += parseInt(caisse.montant);
                    $('#historique-table-body').append('<tr> ' +
                                                            '<td>Tranche '+index+'</td>' +
                                                            '<td style=" text-align: center;">'+caisse.montant+'</td>' +
                                                            '<td style=" text-align: center;">'+caisse.date_save+'</td>' +
                                                        '</tr>'
                    );
                });


            }
         });
     }

     $.ajax({
         url:'?p=caisse.recap_paiement',
         data:'id='+id,
         dataType:'json',
         success:function(json){
             $('#recap-paiement-detail').empty();
             $('#recap-paiement').show();
             $.each(json, function(index, formation){
                 cout_formation = formation.cout_formation;
                 balance = cout_formation - somme_versee;
                 $('#recap-paiement-detail').append('<tr> ' +
                     '<td style=" text-align: center; font-size: 1.2em;">'+cout_formation+' FCFA</td>' +
                     '<td style=" text-align: center; font-size: 1.2em;">'+somme_versee+' FCFA</td>' +
                     '<td style=" text-align: center; font-weight: bold; font-size: 1.2em;">'+balance+' FCFA</td>' +
                     '</tr>'
                 );
             });
             if(balance == 0 ){

                 $('#versement').hide();
                 $('#versement-save').hide();
               //  $('#versement-save').attr('disabled', 'true');
             }else{

                 $('#versement').show();
                 $('#versement-save').show();
               //  $('#versement-save').removeAttr('disabled');
             }
         }
     });

     $('#historique-paiement').show();
 });

 //action sur sauvegarder de la caisse
 $('.form-add-caisse').on('submit', function(e){
     e.preventDefault();
     var $form = $(this);
     var url = $form.attr('action');
     var x = parseInt($('#valeur_monatnt').val()) + parseInt(somme_versee) - parseInt(cout_formation);
    if( x > 0){
        alert_error('Erreur!', 'Montant supérieur au coût de la formation');
     }else{

        $.ajax({
           url:url,
           type: $form.attr('method'),
           data: $form.serialize(),
           success:function(json){
               alert_info('Paiement enrégistré avec succès', 'Frais de formation');
               $('.content-wrapper').html(json, function(){
                   $('.loader').hide();
               });
           }
        });

    }
 });

 $('.form-add').on('submit', function(e){
     e.preventDefault();
     var $form = $(this);
     var url = $form.attr('action');
     $.ajax({
        url:url,
        type: $form.attr('method'),
        data: $form.serialize(),
         dataType:'json',
        success:function(json){

            if(json.erreur == true){
               alert_error(json.message, json.titre);
            }else{
                alert_info(json.message, json.titre);
                $('.content-wrapper').load(json.link);
            }
        }
     });
 });

 $('.desactiver').on('click', function(e){
     e.preventDefault();
     var url = $(this).attr('href');
     swal({
         title: "Voulez-vous vraiment désactiver??",
         text: "Annulation de l'opération en cours",
         type: "warning",
         showCancelButton: true,
         confirmButtonColor: "#DD6B55",
         closeOnConfirm: false,
         confirmButtonText: "Oui, désactiver!",
         showLoaderOnConfirm: true
     }, function(isConfirm){

         $.ajax({
             url:url,
             dataType:'json',
             success:function(json){
                 if(json.erreur){
                     alert_error(json.message, json.titre);
                 }else{
                     alert_info(json.message, json.titre);
                     $('.content-wrapper').load(json.link);
                 }
             }
         });
     });

 });
 $('.activer').on('click', function(e){
     e.preventDefault();
     var url = $(this).attr('href');
     swal({
         title: "Voulez-vous vraiment activer??",
         text: "Annulation de l'opération en cours",
         type: "warning",
         showCancelButton: true,
         confirmButtonColor: "#DD6B55",
         closeOnConfirm: false,
         confirmButtonText: "Oui, activer!",
         showLoaderOnConfirm: true
     }, function(isConfirm){

         $.ajax({
             url:url,
             dataType:'json',
             success:function(json){
                 if(json.erreur){
                     alert_error(json.message, json.titre);
                 }else{
                     alert_info(json.message, json.titre);
                     $('.content-wrapper').load(json.link);
                 }
             }
         });
     });

 });

 function alert_error(titre, messages){
     swal(
         titre,
         messages,
         'error'
     )
 }

 function alert_info(titre, messages){
     swal(titre, messages, 'success')
 }

 $('.annuler').click(function(e){
     e.preventDefault();
     url = $(this).attr('href');
     swal({
         title: "Voulez-vous vraiment annuler??",
         text: "Annulation de l'opération en cours",
         type: "warning",
         showCancelButton: true,
         confirmButtonColor: "#DD6B55",
         closeOnConfirm: false,
         confirmButtonText: "Oui, annuler!",
         showLoaderOnConfirm: true
     }, function(isConfirm){
         $('.loader').show();
         $('.content-wrapper').load(url, function(){
             $('.loader').hide();
         });
     });
 });


 function form_ajax(titre){
   /*  */

     swal({
         title: titre,
         showCancelButton: true,
         showLoaderOnConfirm: true,
         confirmButtonText: 'Enrégistrer',
         reverseButtons: true,
         html:
         '<input id="swal-input1" class="form-control swal2-input" placeholder="Intitulé"/>' +
         '<textarea id="swal-input2" class="swal2-input" placeholder="Description"></textarea>',
         preConfirm: function () {
             return new Promise(function(resolve, reject) {
                     setTimeout(function() {
                         if ( $('#swal-input1').val() === '') {

                             reject('Veuillez renseigner l\'intitulé')

                         } else {
                             resolve([
                                 $('#swal-input1').val(),
                                 $('#swal-input2').val()
                             ])
                         }
                     }, 1000)

             })
         },
         onOpen: function () {
             $('#swal-input1').focus()
         }
     }).then(function (result) {
         swal(JSON.stringify(result))
     }).catch(swal.noop)
 }

 $('.form_ajax').on('click', function(e){
     e.preventDefault();
    //var title = $(this).attr('title');
     //var cible = $(this).attr('href');
     //form_ajax(title);
 });

 $('#choix_formation_pvm').on('change', function(){
     var id = $(this).val();

     if(id != ''){
         $.ajax({
             url:'?p=evaluation.modules',
             data:'id='+id,
             dataType:'json',
             success:function(json){
                 $('loader').show();
                 $('#choix_module_pvm').empty();
                 $('#choix_module_pvm').append('<option selected disabled>Selectionner un module</option>');
                 $.each(json , function(index, module){
                     $('#choix_module_pvm').append('<option value="'+module.idmodule+'">'+module.nom_module+'</option>');
                 });
                 $('loader').hide();
             }
         });
     }
 });

 $('#choix_module_pvm').change(function(e){
     var idM = $(this).val();
     var idF = $('#choix_formation_pvm').val();
     var url = '?p=evaluation.pvm_etudiant&idformation='+idF+'&idmodule='+idM;
     // $('.loader').show();
     $('#pvm_notes').empty();
     $.ajax({
         url:url,
         success:function(json){
             $('#pvm_notes').html(json, function(){
                 $('.loader').hide();
             });
         }
     });
 });

 $(":input").inputmask();
 $(".select2").select2();
 $(".tableau_dynamique").DataTable();
 $('.loader').hide();


