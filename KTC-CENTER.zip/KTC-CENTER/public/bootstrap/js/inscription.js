$(document).ready(function(){
    $('.afficher_sous_menu').click(function(e){
        $('.loader').show();
        e.preventDefault();
        url = $(this).attr('href');
        $('.content-wrapper').load(url, function(){
            $('.loader').hide();
        })
    });

    $('.datepicker').datepicker({
        autoclose: true,
        language: 'fr'
    });

    $(":input").inputmask();
    $(".select2").select2();
    $('.loader').hide();
});

$('.annuler').click(function(e){
    e.preventDefault();
    url = $(this).attr('href');
    swal({
        title: "Voulez-vous vraiment annuler????",
        text: "Annulation de l'opération en cours...",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        closeOnConfirm: false,
        confirmButtonText: "Oui, annuler!",
        showLoaderOnConfirm: true
    }, function(isConfirm){
        document.location.replace(url);
    });
});

$('.choix_formation').change(function(){
    if($(this).val() != null) {
        var idF = $(this).val();
        var url = "?p=inscription.load&id="+idF;
        $.ajax({
            url: url,
            success: function (json) {
                $('#div_module').html(json);
            }
        });
    }else{
        $('#div_module').empty();
    }
});





