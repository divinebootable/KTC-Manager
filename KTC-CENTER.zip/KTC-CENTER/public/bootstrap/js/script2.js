    $('#choix_formation').change(function(e){
        var a = $(this).val();
        var url = '?p=formation_module.nouveau';
       // $('.loader').show();
        $('#afficher_module_formation').empty();
        $.ajax({
            url:url,
            data:'id='+a,
            success:function(json){
               $('#afficher_module_formation').html(json, function(){
                   $('.loader').hide();
               });
            }
        });
    });

    $('.afficher').click(function(e){
        $('.loader').show();
        e.preventDefault();
        url = $(this).attr('href');
        $('.content-wrapper').load(url, function(){
            $('.loader').hide();
        })
    });

    $('.annuler').click(function(e){
        e.preventDefault();
        url = $(this).attr('href');
        swal({
            title: "Voulez-vous vraiment annuler??",
            text: "Annulation de l'opération en cours",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            closeOnConfirm: false,
            confirmButtonText: "Oui, annuler!",
            showLoaderOnConfirm: true
        }, function(isConfirm){
            $('.loader').show();
            $('.content-wrapper').load(url, function(){
                $('.loader').hide();
            });
        });
    });
    $('.form-delete').submit(function(e){
        e.preventDefault();
        var $form = $(this);
        var url = $form.attr('action');
        swal({
                title: "Voulez-vous vraiment supprimer cet élément?",
                text: "Cette opération est irreversible!",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                closeOnConfirm: false,
                confirmButtonText: "Oui, supprimer!",
                showLoaderOnConfirm: true
            },
            function(isConfirm){

                    $.ajax({
                        url:url,
                        type:$form.attr('method'),
                        data:$form.serialize(),
                        success:function(json){
                            swal('Suppression!',
                                 'effectuée avec succès',
                                 'success'
                            );
                            $('.loader').show();
                            $('.content-wrapper').load(url, function(){
                                $('.loader').hide();
                            });
                        }
                    });

            });
    });

    $('.form-add').submit(function(e){
        e.preventDefault();
        var $form = $(this);
        var url = $form.attr('action');
        // alert(url);
        $('.loader').show();
        $.ajax({
            url:url,
            type:$form.attr('method'),
            data:$form.serialize(),
            success:function(json){
                $('.content-wrapper').html(json, function(){
                    $('.loader').hide();
                });
            }
        });
    });
    //saisir les notes
    $('#evaluation_formation').on('change', function(){
        var id = $(this).val();
        $('#evaluation_module').empty();
        if(id != ''){
            $.ajax({
                url:'?p=evaluation.modules',
                data:'id='+id,
                dataType:'json',
                success:function(json){
                    $('#evaluation_etudiant_body').empty();
                    $('#evaluation_module').append('<option selected disabled>Selectionner un module</option>');
                    $.each(json , function(index, module){
                        $('#evaluation_module').append('<option value="'+module.idmodule+'">'+module.nom_module+'</option>');
                    });
                }
            });
        }
    });
    $('#evaluation_module').on('change', function(){
        var id = $(this).val();
        $('#evaluation_note').empty();
        if(id != ''){
            $.ajax({
                url:'?p=evaluation.notes',
                data:'id='+id,
                dataType:'json',
                success:function(json){
                    $('#evaluation_etudiant_body').empty();
                    $('#evaluation_note').append('<option selected disabled>Selectionner le type de note</option>');
                    $.each(json , function(index, note){
                        $('#evaluation_note').append('<option value="'+note.idnote+'">'+note.type_note+'</option>');
                    });
                }
            });
        }
    });

    $('#evaluation_note').on('change', function(){
        var idnote = $(this).val();
        var idformation = $('#evaluation_formation').val();
        var idmodule = $('#evaluation_module').val();

        // alert(idnote+' '+idformation+' '+idmodule);
        $('#evaluation_etudiant').empty();
        if (!(idnote != '' && idformation != '' && idmodule != '')) {
        } else {
            $.ajax({
                url: '?p=evaluation.etudiants',
                data: {'idformation': idformation, 'idmodule': idmodule, 'idnote': idnote},
                dataType: 'json',
                success: function (json) {
                   $('#tableau_note').show();
                    $('#evaluation_etudiant_body').empty();
                    $.each(json, function (index, etudiant) {
                        index++;
                        $('#evaluation_etudiant_body').append(
                            '<tr>' +
                            '<td>' + index + '</td>' +
                            '<td><input type="hidden" name="idetudiant[]" value="' + etudiant.idetudiant + '">' + etudiant.matricule + '</td>' +
                            '<td>' + etudiant.nom + ' ' + etudiant.prenom + '</td>' +
                            '<td><input type="text" placeholder="00.00" pattern="[0-9]{1}\.[0-9]{2}|1[0-9]{1}\.[0-9]{2}|20\.00" class="form-control" name="moyenne[]" required></td>' +
                            '</tr>');
                    });

                }
            });
        }
    });

    //consulter les notes

    $('#evaluation_formation_consulter').on('change', function(){
        var id = $(this).val();
        $('#evaluation_module_consulter').empty();
        if(id != ''){
            $.ajax({
                url:'?p=evaluation.modules',
                data:'id='+id,
                dataType:'json',
                success:function(json){
                    $('loader').show();
                    $('#liste_note_consulter').empty();
                    $('#evaluation_module_consulter').append('<option selected disabled>Selectionner un module</option>');
                    $.each(json , function(index, module){
                        $('#evaluation_module_consulter').append('<option value="'+module.idmodule+'">'+module.nom_module+'</option>');
                    });
                    $('loader').hide();
                }
            });
        }
    });
    $('#evaluation_module_consulter').on('change', function(){
        var id = $(this).val();
        $('#liste_note_consulter').empty();
        if(id != ''){
            $.ajax({
                url:'?p=evaluation.notes_consulter',
                data:'id='+id,
                dataType:'json',
                success:function(json){
                    $('loader').show();
                    $('#liste_note_consulter').empty();
                    $('#evaluation_note_consulter').empty();
                    $('#evaluation_note_consulter').append('<option selected disabled>Selectionner le type de note</option>');
                    $.each(json , function(index, note){
                        $('#evaluation_note_consulter').append('<option value="'+note.idnote+'">'+note.type_note+'</option>');
                    });
                    $('loader').hide();
                }
            });
        }
    });

    $('#evaluation_note_consulter').on('change', function(){
        var idnote = $(this).val();
        var idformation = $('#evaluation_formation_consulter').val();
        var idmodule = $('#evaluation_module_consulter').val();

        // alert(idnote+' '+idformation+' '+idmodule);
        $('#liste_note_consulter').empty();
        if (!(idnote != '' && idformation != '' && idmodule != '')) {
        } else {
            $.ajax({
                url: '?p=evaluation.etudiants_consulter',
                data: {'idformation': idformation, 'idmodule': idmodule, 'idnote': idnote},
                dataType: 'json',
                success: function (json) {
                    $('loader').show();
                    $.each(json, function (index, etudiant) {
                        index++;
                        $('#liste_note_consulter').append(
                            '<table class="table table-bordered table-hover table-advance tableau_dynamique">'+
                                '<thead>'+
                                    '<th>#</th>'+
                                     '<th>Matricule</th>'+
                                     '<th width="50%">Noms et prénoms</th>'+
                                     '<th>Note/20</th>'+
                                     '<th>Actions</th>'+
                                '</thead>'+
                                '<tbody>'+
                                    '<tr>' +
                                        '<td>' + index + '</td>' +
                                        '<td><input type="hidden" name="idetudiant[]" value="' + etudiant.idetudiant + '">' + etudiant.matricule + '</td>' +
                                        '<td>' + etudiant.nom + ' ' + etudiant.prenom + '</td>' +
                                        '<td><input type="text" value="00.00" pattern="[0-9]{1}\.[0-9]{2}|1[0-9]{1}\.[0-9]{2}|20\.00" disabled class="form-control moyenne" value="'+etudiant.moyenne+'" name="moyenne[]" required></td>' +
                                        '<td> ' +
                                            '<button class="btn btn-success editer_moyenne"><i class="fa fa-check"></i>Editer</button>' +
                                        '</td>' +
                                    '</tr>' +
                                '</tbody>' +
                            '</table>');
                    });
                    $('loader').hide();
                }
            });
        }
    });

    $('.editer_moyenne').on('click', function(){
        //$('.moyenne').removeAttr('disabled');
        alert
    });

    $('.datepicker').datepicker({
        autoclose: true,
        language: 'fr'
    });
    $(":input").inputmask();
    $(".select2").select2();
    $(".tableau_dynamique").DataTable();
    $('.loader').hide();
