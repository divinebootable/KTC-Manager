$(':checkbox').click(function() {
    var idM = $(this).val();
    var idF = $('#choix_formation').val();
    var valeur;
    // alert('ok');
    if(this.checked){ // si 'checkAll' est coché
        valeur = true;
    }else{ // si on décoche 'checkAll'
        valeur = false;
    }
    var url = "?p=formation_module.save";
    $.ajax({
        url:url,
        data:{'idmodule':idM, 'idformation':idF, 'operation':valeur},
        success:function(json){

        }
    });
});

//Red color scheme for iCheck

/*$('input[type="checkbox"]').iCheck({
    checkboxClass: 'icheckbox_flat-green',
    radioClass: 'iradio_flat-blue'
});*/


