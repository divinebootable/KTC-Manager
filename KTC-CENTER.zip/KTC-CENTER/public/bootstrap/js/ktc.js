$(document).ready(function(){
       $('.afficher_sous_menu').click(function(e){
        $('.loader').show();
        e.preventDefault();
        url = $(this).attr('href');
        $('.content-wrapper').load(url, function(){
            $('.loader').hide();
        })
    });
    $('.loader').hide();
});



