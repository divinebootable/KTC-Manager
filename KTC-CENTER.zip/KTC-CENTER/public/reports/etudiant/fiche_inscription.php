<?php

?>


    <!-- Main content -->
    <section class="invoice">

        <div class="row invoice-info">
            <div class="col-sm-4 invoice-col text-center">

                <strong>REPUBLIQUE DU CAMEROUN</strong><br>**********<br>
                <strong>MINISTERE DE L'EMPLOI ET DE LA FORMATION PROFESSIONNELLE</strong><br>**********<br>
                <strong>CENTRE DE FORMATION PROFESSIONNEL       KTC-CENTER</strong><br>**********<br>
                <address>
                  BP: 13501 Yaoundé, Tél: 222 313 342/676 544 214<br>
                  Email: info@kamer-center.net, www.kamer-center.net
                </address>
            </div>
            <!-- /.col -->
            <div class="col-sm-4 invoice-col text-center">
               <img src="../../dist/img/logo.png">
            </div>
            <!-- /.col -->
            <div class="col-sm-4 invoice-col text-center">
                <strong>REPUBLIC OF CAMEROON</strong><br>**********<br>
                <strong>MINISTRY OF EMPLOYMENT AND VOCATIONAL TRAINING</strong><br>**********<br>
                <strong>VOCATIONAL TRAINING CENTER KTC-CENTER</strong><br>**********<br>
                <address>
                   PO BOX: 13501 Yaoundé, Tél: 222 313 342/676 544 214<br>
                   Email: info@kamer-center.net, www.kamer-center.net
                </address>
            </div>
            <!-- /.col -->
        </div>

        <div class="row">
            <div class="col-xs-12">

                <div class="col-lg-8 titre-fiche">FICHE D'INSCRIPTION AU DQP 2018</div>

            </div>
        </div>
    </section>
    <!-- /.content -->
</div>
<!-- ./wrapper -->
</body>
</html>

<style>
    .invoice-info{
        font-size: 0.60em;;
    }
    .titre-fiche{
        border:solid black 3px;
        text-align: center;
        font-size: 1.8em;
        font-weight: bold;
        width: 72%;
        margin-left: 13%;
        margin-top: 2%;
        margin-bottom: 2;
    }
</style>