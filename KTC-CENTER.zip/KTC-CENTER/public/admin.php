<?php
define('ROOT', dirname(__DIR__));
require ROOT.'/app/App.php';
App::load();
if(isset($_GET['p'])){

    $page = $_GET['p'];
}else{

    $page = 'home';
}

ob_start();
if($page === 'home'){
    require ROOT . '/Views/formation/index.php';
}else if($page==='single'){

    require ROOT . '/Views/formation/show.php';
}
$content = ob_get_clean();

require ROOT . '/Views/template/Logged.php';
