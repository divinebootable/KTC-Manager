<?php
    define('ROOT', dirname(__DIR__));
    require ROOT.'/app/App.php';
    use Core\Auth\DbAuth;
    App::load();
   if(isset($_GET['p']) && !empty($_GET['p'])){
       $page = $_GET['p'];
   }else{
       $page = 'login';
   }
    $page = explode('.', $page);
    $action = 'introuvable';
    $controleur = '\App\Controller\LoginController';
    if($page[0] == 'login'){
        $controleur = '\App\Controller\\'.ucfirst($page[0]).'Controller';
        $action = $page[0];
    }else if($page[0] == 'home'){
        $controleur = '\App\Controller\Logged\\'.ucfirst($page[0]).'Controller';
        $action =   $page[0];
    }else if($page[0] == 'inscription'){
        $controleur = '\App\Controller\\'.ucfirst($page[0]).'Controller';
        $action =   $page[1];
    }else if($page[0] == 'fichiers'){
        $controleur = '\App\Controller\\Logged\\'.ucfirst($page[0]).'Controller';
        $action = $page[1];
    }else{
            $file = ucfirst($page[0]).'Controller.php';
            if(in_array($file, scandir('../app/Controller/Logged'))){
              $vue = isset($page[1]) ? $page[1] : $page[0];
                if(in_array($vue.'.php', scandir('../app/Views/Logged/'.$page[0]))){
                    $controleur = '\App\Controller\Logged\\'.ucfirst($page[0]).'Controller';
                    $action = $vue;
                }else{
                    $controleur = '\App\Controller\LoginController';
                    $action = 'introuvable';
                }
            }else{
                $controleur = '\App\Controller\LoginController';
                $action = 'introuvable';
            }
    }

    $controleur = new $controleur;
    $controleur->$action();

?>

