<?php

    return array(

        "db_host" => "localhost",
        "db_nom" => "ktcmanager",
        "db_user" => "ktcmanager",
        "db_pass" => "ktcmanager#2017"


    );
	//user: admin2	
	//pass: admin#2017

?>